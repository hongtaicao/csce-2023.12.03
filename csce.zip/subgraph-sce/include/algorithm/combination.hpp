/*
 * combination.hpp
 *
 *  Created on: 14:03 PM Sunday 2022-11-06
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ALGORITHM_COMBINATION_HPP_
#define INCLUDE_ALGORITHM_COMBINATION_HPP_

#include <cstdlib>      // size_t
#include <unordered_set>

namespace algorithm {

class Combination {
public:
    typedef std::unordered_set<size_t> choice_t;
    /* a combination generator for n choose k
     * (0,0) -> out of range
     * (0,1) -> out of range
     * (1,0) -> out of range
     * (1,1) -> [0]
     * (2,1) -> [0], [1]
     * (2,2) -> [0,1]
     * (3,2) -> [0,1], [0,2], [1,2]
     */
    Combination(const size_t, size_t);
    ~Combination() {
        delete[] this->data_;
    }

    inline size_t operator[](size_t index) const {
        return this->data_[index];
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    inline void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
#endif

    inline bool InRange() const {
        return this->in_range_;
    }

    void Next();

    void PrintDetail(bool) const;

    inline size_t Size() const {
        return this->size_;
    }

    choice_t ToSet() const;

private:
    size_t *data_;
    bool in_range_;
    const size_t offset_, size_;
};

} // namespace algorithm

#endif /* INCLUDE_ALGORITHM_COMBINATION_HPP_ */
