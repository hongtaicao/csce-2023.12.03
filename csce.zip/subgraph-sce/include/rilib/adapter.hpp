/*
 * adapter.hpp
 *
 *  Created on: Jul 5, 2023
 *      Author: hongt
 */

#ifndef INCLUDE_RILIB_ADAPTER_HPP_
#define INCLUDE_RILIB_ADAPTER_HPP_

// header used by rilib
#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <string>

#include "include/common.hpp"

/* the following 3 files are copied from github.com/InfOmics/RI
 * 350d4bb on Apr 26, 2022
 *
 * RI: 2013-A subgraph isomorphism algorithm and its application
 * to biochemical data
 */
#include "include/rilib/Graph.h"
#include "include/rilib/MatchingMachine.h"
#include "include/rilib/MaMaConstrFirst.h"

namespace csr {

namespace codegen {

class Query;

} // namespace codegen

} // namespace csr

namespace rilib {

// The static search strategy in RI
void MatchVertex(csr::codegen::Query&, string_1d_t &match_vertex);

} //namespace rilib

#endif /* INCLUDE_RILIB_ADAPTER_HPP_ */
