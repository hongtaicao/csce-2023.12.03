/*
 * graph.hpp
 *
 * a graph using edge list format
 *
 *  Created on: 23:19 PM Friday Sep 15, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_EDGELIST_GRAPH_HPP_
#define INCLUDE_EDGELIST_GRAPH_HPP_

#include <string>

#include "include/common.hpp"
#include "include/edgelist/label.hpp"

namespace utility {
class Config;
} // namespace utility

namespace edgelist {

typedef typename utility::Config Config;

template<typename T1, typename T2>
void GetEdgeToIndex(const edge_map_t &out_edge, edge_to_array4_t &label_map,
        string_index_t &labelstr_index, T1 ToIndex, T2 &edge_to_index) {
    for (const auto &v_neighbor : out_edge) {
        auto str_a = std::to_string(v_neighbor.first);
        for (const auto &vb : v_neighbor.second) {
            auto str_b = std::to_string(vb);
            auto edge_str = str_a + " " + str_b;
            const auto &label_array = label_map[edge_str];
            auto index = labelstr_index[LabelarrayToString(label_array)];
            edge_to_index[edge_str] = ToIndex(index);
            if (label_array[3] == OutgoingEdgeLabel) {
                /* out_edge saves out-going edges only
                 * add the in-coming edges if the edge is not bi-directed
                 */
                auto in_edge_str = str_b + " " + str_a;
                auto in_label_array = label_map[in_edge_str];
                in_label_array[3] = IncomingEdgeLabel;
                auto index = labelstr_index[LabelarrayToString(in_label_array)];
                edge_to_index[in_edge_str] = ToIndex(index);
            }
        }
    }
}

void GetVertexLabel(const edge_map_t&, edge_to_array4_t&, size_t,
        string_1d_t&);

template<typename T>
void GetVertexPairLabel(const string_1d_t &vertex_to_label, T &vp_to_index) {
    /* used for VertexInduced negation
     * insert label for all vertex pairs
     */
    for (size_t va = 0; va < vertex_to_label.size(); va++) {
        const std::string &la = vertex_to_label[va];
        for (size_t vb = 0; vb < vertex_to_label.size(); vb++) {
            if (va != vb) {
                vp_to_index[la + " " + vertex_to_label[vb]];
            }
        }
    }
}

// used for VertexInduced. see csr/codegen/query, csr/query
template<typename T1, typename T2>
void GetVertexPairToIndex(const string_index_t &clusterkey_index, T1 ToIndex,
        T2 &vplabel_to_index) {
    /* used for VertexInduced negation
     * compute all edge indices that match the labels of the given vertex pair
     */
    for (const auto &pair : clusterkey_index) {
        // find the second space
        size_t n = 0;
        size_t space_count = 0;
        for (; n < pair.first.size(); n++) {
            if (pair.first[n] == ' ') {
                space_count += 1;
                if (space_count >= 2) {
                    break;
                }
            }
        }
        // the label of a vertex pair
        const std::string vp_label = pair.first.substr(0, n);
        if (vplabel_to_index.count(vp_label)) {
            /* labelstr_index is a hash map
             * so it guarantees the same key appears only once
             * therefore pair.second never contain duplicates
             */
            vplabel_to_index[vp_label].push_back(ToIndex(pair.second));
        }
    }
}

void GetVertexSet(const edge_map_t &, vid_set_t &);

vid_t MaxDegree(const edge_map_1d_t &);

vid_t MaxVertex(const edge_map_t &);

// can read both labeled and unlabeled graph, but process as labeled
void ReadGraphText(bool, const std::string &, edge_map_t &,
        edge_to_array4_t &);

vid_t ReadGraphTextToGraphs(Config &, edge_map_1d_t &, string_index_t &);

void WriteGraphText(string_index_t&, const std::string&, const std::string&);

} // namespace edgelist

#endif /* INCLUDE_EDGELIST_GRAPH_HPP_ */
