/*
 * label.hpp
 *
 * graph label file
 *
 *  Created on: 5:24 AM Friday Sep 15, 2023
 *      Author: hongt Hongtai
 */

#ifndef INCLUDE_EDGELIST_LABEL_HPP_
#define INCLUDE_EDGELIST_LABEL_HPP_

#include <array>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"

namespace edgelist {

typedef std::array<eid_t, 4> array4_t;
typedef std::vector<array4_t> array4_1d_t;
typedef std::unordered_map<std::string, array4_t> edge_to_array4_t;

void ReadLabelFileText(const std::string &, string_index_t &);
void WriteLabelFileText(const std::string &, const edge_to_array4_t &,
        string_index_t &);

} // namespace edgelist

#endif /* INCLUDE_EDGELIST_LABEL_HPP_ */
