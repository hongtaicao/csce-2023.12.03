/*
 * graph.hpp
 *
 * represent the data graph
 *
 *  Created on: 0:05 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_GRAPH_HPP_
#define INCLUDE_CSR_GRAPH_HPP_

#include <string>

#include "include/common.hpp"
#include "include/csr/neighborset.hpp"
#include "include/optim/graph.hpp"

namespace utility {

class Config;

} // namespace utility

namespace csr {

void BuildGraphBinary(utility::Config &);

class Graph: public optim::Graph {
public:
    Graph(utility::Config &);
    ~Graph();

    inline eid_t EdgeCount(const csize_t cluster_index) const override {
        auto root_size = this->RootSize(cluster_index);
        if (root_size > 0) {
            auto row_index = this->row_index_[cluster_index];
            return row_index[root_size] - row_index[0];
        }
        // graph has no edges under this label_index
        return 0;
    }
    inline NeighborSet LN(const csize_t c_index, const vid_t vertex) const {
        /* c_index (cluster_index): the i-th label of the label file
         * a label refers to a graph containing edges (a, b) such that
         * all labels of vertex a are the same
         * all labels of vertex b are the same
         * all edge labels between (a, b) are the same
         * all topology between (a, b) are the same, one of a->b, a<-b, a<->b
         *
         * a graph consists of multiple CSR graphs
         * each consists edges of the same label array
         * the c_index is the index to one of CSR graphs
         */
        rid_t begin = this->row_index_[c_index][vertex];
        rid_t end = this->row_index_[c_index][vertex + 1];
        cid_t *neighbor = this->column_index_[c_index];
        return NeighborSet(neighbor + begin, end - begin);
    }

    inline vid_t MaxCandidateSize(const vid_t query_vertex_count) const {
        /* the design of this method is to save duplicate Query object
         * if this->query_size_ is set
         * then query_vertex_count can be supplied by this->QuerySize()
         * otherwise need to obtain Query.VertexCount()
         *
         * it is safe to use graph.VertexSize() as VertexSet max size
         * and this is useful when the query contains no edges
         * because all graph vertices can be candidates.
         *
         * due to injective and negation
         * the max size can depend on query vertex count
         */
        if (query_vertex_count > this->MaxDegree()) {
            return query_vertex_count;
        }
        return this->MaxDegree();
    }

    inline NeighborSet N(const vid_t vertex) const {
        /* undirected unlabeled neighbor
         * it has only 1 label and the index of the label is 0
         * therefore the first indexes of row_index_ and column_index are 0
         *
         * also the in-coming neighbor vertices of unlabeled graphs
         */
        rid_t begin = this->row_index_[0][vertex];
        rid_t end = this->row_index_[0][vertex + 1];
        cid_t *neighbor = this->column_index_[0];
        return NeighborSet(neighbor + begin, end - begin);
    }
    inline NeighborSet N(const vid_t vertex, const vid_t up) const {
        /* undirected unlabeled neighbor of vertex and smaller than up
         * also the in-coming neighbor vertices of unlabeled graphs
         */
        rid_t begin = this->row_index_[0][vertex];
        rid_t end = this->row_index_[0][vertex + 1];
        cid_t *neighbor = this->column_index_[0];
        return NeighborSet(neighbor + begin, end - begin, up);
    }
    inline NeighborSet O(const vid_t vertex) const {
        // outgoing neighbor vertices of unlabeled graphs
        rid_t begin = this->row_index_[1][vertex];
        rid_t end = this->row_index_[1][vertex + 1];
        cid_t *neighbor = this->column_index_[1];
        return NeighborSet(neighbor + begin, end - begin);
    }
    inline NeighborSet O(const vid_t vertex, const vid_t up) const {
        // outgoing neighbor vertices of unlabeled graphs and smaller than up
        rid_t begin = this->row_index_[1][vertex];
        rid_t end = this->row_index_[1][vertex + 1];
        cid_t *neighbor = this->column_index_[1];
        return NeighborSet(neighbor + begin, end - begin, up);
    }
    inline vid_t OutDegree(const csize_t cluster_index, const vid_t irow) const
            override {
        auto row_index = this->row_index_[cluster_index];
        return row_index[irow + 1] - row_index[irow];
    }
    inline vid_t OutVertex(const csize_t c_idx, const vid_t irow,
            const vid_t icol) const override {
        return this->column_index_[c_idx][this->row_index_[c_idx][irow] + icol];
    }
    inline vid_t QuerySize() const {
        // if data graph does not read the query, then query_size_ is 0
        return this->query_size_;
    }
    inline vid_t RootSize(const csize_t cluster_index) const override {
        return this->row_size_[cluster_index];
    }
    inline vid_t RootVertex(const csize_t, const vid_t irow) const override {
        return irow;
    }

    void WriteEdgelistText(const std::string &, const std::string &) const
            override;

private:
    vid_t query_size_;

    vid_t *row_size_; // row_size_[i] is (1 + the size of row_index_[i])
    /*
     * graph data is represented in CSR format
     * 1. fast neighbor intersection, for worst-case optimal join
     * 2. symmetry breaking
     *
     * each CSR is further clustered by a label array, as a tuple
     * (vlabel, vlabel, elabel, topology)
     *
     * the CSR format of a graph under cluster index 0 is
     * c = column_index_[0]
     * r = row_index_[0]
     *
     * the neighbor vertices of vertex v=1 is a sub-array in c
     * [c[begin_index], c[end_index])
     * begin_index = r[v=1]
     * end_index = r[v+1]
     */
    cid_t **column_index_;
    rid_t **row_index_;
};

} // namespace csr

#endif /* INCLUDE_CSR_GRAPH_HPP_ */
