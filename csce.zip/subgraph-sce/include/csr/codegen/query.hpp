/*
 * query.hpp
 *
 * represent the query / pattern graph
 * use out_edge to fast test edge between vertex pairs
 *
 * this is designed for codegen statement, therefore everything is eagerly
 * stored as string
 *
 *  Created on: 0:05 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_CODEGEN_QUERY_HPP_
#define INCLUDE_CSR_CODEGEN_QUERY_HPP_

#include <string>
#include <unordered_map>

#include "include/common.hpp"

namespace csr {

namespace codegen {

class Query {
public:
    Query(const std::string&, const std::string&, bool);

    const string_1d_t& AllClusterIndex(const std::string &va,
            const std::string &vb) {
        /* retrieve NeighborSet that match vertex labels
         * used in codegen/statement for VertexInduced case
         */
        return this->vplabel_to_edgeindex_[this->string_vertex_to_label_[va]
                + " " + this->string_vertex_to_label_[vb]];
    }

    // the number of neighbor vertices of a vertex
    size_t Degree(const std::string &);

    inline bool HasEdge(const vid_t va, const vid_t vb) {
        return this->vid_out_edge.count(va) and this->vid_out_edge[va].count(vb);
    }

    inline bool HasEdge(const std::string &va, const std::string &vb) {
        return this->string_out_edge_.count(va)
                and this->string_out_edge_[va].count(vb);
    }

    inline size_t InDegree(const std::string &v) {
        return this->string_in_edge_[v].size();
    }

    inline const std::string& Index(const std::string &va,
            const std::string &vb) {
        /* return the index of graph containing all edges like (va, vb)
         * this includes
         * - vertex a label
         * - vertex b label
         * - the edge label
         * - the topology (bi-directed, in-coming, out-going)
         * requirement: a, b are vertices and a->b
         */
        return this->edge_to_cindex_[va + " " + vb];
    }

    inline csize_t IndexCount() const {
        /* used by codegen/statement to determine
         * whether a labeled query can be processed as unlabeled
         * (all labels are the same)
         *
         * number of unique label array of 4 labels
         * (vertex a label, vertex b label, edge label, topology label)
         * each unique label array has one edge index
         */
        return this->index_count_;
    }

    bool IsVertexSet(const string_set_t&);

    inline std::string& Label(int vertex) {
        // used by rilib/adapter
        return this->int_vertex_to_label_[vertex];
    }

    inline std::string& Label(const std::string &vertex) {
        // used by statement for DSet
        return this->string_vertex_to_label_[vertex];
    }

    inline size_t OutDegree(const std::string &v) {
        return this->string_out_edge_[v].size();
    }

    inline size_t VertexCount() const {
        return this->vertex_set_.size();
    }

    // used by rilib/adapter
    edge_map_t vid_out_edge;

private:
    csize_t index_count_;
    string_1d_t int_vertex_to_label_;

    /* index the corresponding CSR from data graph
     * include both in-coming and out-going edges
     */
    string_map_t edge_to_cindex_;
    string_map_t string_vertex_to_label_;

    // out-going edge map
    std::unordered_map<std::string, string_set_t> string_out_edge_;
    // in-coming edge map
    std::unordered_map<std::string, string_set_t> string_in_edge_;

    /* for VertexInduced negation to remove false candidate vertices
     * map a vertex label to all edge indices that it connects
     *
     * important design choice
     * consider an example
     * v0 and v1 connect, v1 and v2 connect, v1 and v3 connect
     * v0 and v2 are not connected
     * v0 and v3 are not connected
     *
     * to remove from v2 candidates, e.g., e1v1, that connect v0
     * only needs edge index that matches the label of the edge (v0, v2)
     * e.g., e10 (edge label 0), e100(edge label 10), ...
     * then v2 candidates need to compute VertexSet e10e100d0e1v1
     *
     * to remove from v3 candidates, e.g., e1v1, that connect v0
     * only needs edge index that matches the label of (v0, v3),
     * in this case, it must be the same as v2 candidate case
     * then e10e100d0e1v1 can be shared
     *
     * big benefit
     * such sharing has to checked every time during dynamic execution
     * for all candidates of v0, v1, v2, v3 because the result depends on
     * the data and query graphs.
     * However, given the data and query graphs, the result is constant
     * and therefore compiled plans can save time
     *
     * after v0, v1 are considered
     * e10e100d0e1v1 is further used to compute v3 candidates by
     * looking at v2 and v3 connection
     *
     * note that edge indices that match label of (v0, *)
     * will not remove candidates if vertex * label does not match v2
     * so over removal is wasteful
     *
     * there is no need to keep track of all edge indices as long if
     * removing candidates that connect to v0, so e10e100 can be dropped
     */
    str_to_str_1d_t vplabel_to_edgeindex_;

    vid_set_t vertex_set_;
};

} // namespace codegen

} // namespace csr

#endif /* INCLUDE_CSR_CODEGEN_QUERY_HPP_ */
