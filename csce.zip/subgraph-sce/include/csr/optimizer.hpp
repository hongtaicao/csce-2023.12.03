/*
 * optimizer.hpp
 *
 *  Created on: Wednesday 16:59 PM, Jul 5, 2023
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_OPTIMIZER_HPP_
#define INCLUDE_CSR_OPTIMIZER_HPP_

#include "include/common.hpp"

namespace utility {
class Config;
}

namespace csr {

class Graph;

typedef utility::Config Config;

namespace codegen {

class Query;

}

void BuildMatchVertex(Config&, Graph&, codegen::Query&, string_1d_t&);

} // namespace csr

#endif /* INCLUDE_CSR_OPTIMIZER_HPP_ */
