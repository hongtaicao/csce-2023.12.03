/*
 * utility.hpp
 *
 *  Created on: 3:02 AM Wednesday Aug 30, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_UTILITY_HPP_
#define INCLUDE_CSR_UTILITY_HPP_

#include <cstdint>          // uint64_t
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/utility/utility.hpp"

namespace utility {

class Config;
class Logger;

} // namespace utility

namespace csr {

class Graph;

using expression_t = void (*)(const Graph &);

typedef utility::Config Config;
typedef utility::Logger Logger;

typedef std::vector<vid_t> result_1d_t;
typedef std::vector<result_1d_t> result_2d_t;
// function with Argument as argument and ReturnType as return type
typedef std::unordered_map<std::string, expression_t> expression_map_t;

// declare variable
extern uint64_t COUNTER;
extern std::ofstream OUTPUT;
extern result_2d_t RESULT;

using utility::COUNTER_LOOP_0;
using utility::COUNTER_LOOP_1;
using utility::COUNTER_LOOP_2;
using utility::COUNTER_LOOP_3;
using utility::COUNTER_LOOP_4;
using utility::COUNTER_LOOP_5;

#ifdef MEASURE_PERFORMANCE
#define AddOne(x)   (x++)
#else
#define AddOne(x)   (void (0))
#endif

uint64_t After(Config &);
bool Before(Config &, const vid_t);
bool ExecuteByQueryName(Config &, const Graph &, Logger &, expression_map_t &,
        const vid_t size_t);

} // namespace csr

#endif /* INCLUDE_CSR_UTILITY_HPP_ */
