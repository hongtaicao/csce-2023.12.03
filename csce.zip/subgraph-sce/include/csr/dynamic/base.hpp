/*
 * base.hpp
 *
 * a base class for dynamic execution of subgraph matching for
 * EdgeInduce
 * Homomorphism
 * VertexInduce
 *
 *  Created on: 5:17 AM Monday Sep 25, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_DYNAMIC_BASE_HPP_
#define INCLUDE_CSR_DYNAMIC_BASE_HPP_

#include "include/common.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/query.hpp"
#include "include/csr/utility.hpp"
#include "include/csr/vertexset.hpp"

#ifdef EARLY_TERMINATE
#define EarlyTerminate              return true;
#define EarlyTerminateSize0(x)      if (x.size == 0) {return true;}
#define EarlyTerminateTrue(x)       if (x) {return true;}
#else
#define EarlyTerminate              ((void) 0)
#define EarlyTerminateSize0(x)      ((void) 0)
#define EarlyTerminateTrue(x)       x;
#endif

namespace csr {

class NeighborSet;

namespace dynamic {

typedef std::vector<NeighborSet> NeighborSet_1d_t;

#ifndef NDEBUG
#define NDEBUG
#endif

// public utility function
#ifdef NDEBUG
inline void DebugPrint(const size_t, const size_t, const NeighborSet&) {
}

inline void DebugPrint(const size_t, const size_t, const VertexSet&) {
}
#else
inline void DebugPrint(const size_t pi, const size_t ci,
        const NeighborSet &nset) {
    DPrint("NSet(" << pi << "," << ci << ") data=" << nset.data << " size=");
    DPrintLine(nset.size);
}

inline void DebugPrint(const size_t pi, const size_t ci,
        const VertexSet &vset) {
    DPrint("VSet(" << pi << "," << ci << ") data=" << vset.data << " size=");
    DPrintLine(vset.size);
}
#endif

template<typename T>
void DSet(VertexSet &vset_o, const T &vset_i, const NeighborSet_1d_t &nset_1d) {
    /* labels of vset_o and vertex do not match
     * only need to exclude vertex NeighborSet
     * note that output vset_o can be the argument as input vset_i
     */
    vset_o.DSet(vset_i, nset_1d[0]);
    for (size_t ith = 1; ith < nset_1d.size(); ith++) {
        vset_o.DSet(vset_o, nset_1d[ith]);
    }
}

template<typename T>
void DSet(VertexSet &vset_o, const T &vset_i, vid_t vertex,
        const NeighborSet_1d_t &nset_1d) {
    /* labels of vset_o and vertex match
     * need to further exclude vertex
     * note that output vset_o can be the argument as input vset_i
     */
    vset_o.DSet(vset_i, vertex, nset_1d[0]);
    for (size_t ith = 1; ith < nset_1d.size(); ith++) {
        vset_o.DSet(vset_o, nset_1d[ith]);
    }
}

#if !defined(COUNTING) and defined(LISTING)
void OutputResult(const vid_1d_t &);
// non-inline function can only have declaration in the header file
#elif !defined(COUNTING) and defined(MEMORY)
inline void OutputResult(const vid_1d_t &result) {
    RESULT.push_back(result);
}
#else
inline void OutputResult(const vid_1d_t &) {
    // default COUNTING
    COUNTER += 1;
}
#endif

class Base {
public:
    Base(const Graph &graph, csr::Query &query,
            const vid_1d_t &match_vertex)
            : graph_(graph), query_(query), match_vertex_(match_vertex) {
    }
    virtual ~Base() {
    }

protected:
    inline NeighborSet IndexNeighborSet(const csize_t edge_index,
            const vid_t vertex) const {
        return this->graph_.LN(edge_index, vertex);
    }

    inline NeighborSet IndexNeighborSet(const size_t pi, const size_t ci,
            const vid_t vertex) const {
        auto va = this->match_vertex_[pi];
        auto vb = this->match_vertex_[ci];
        return this->graph_.LN(this->query_.Index(va, vb), vertex);
    }

    /* each vertex=match_vertex_[ith] can compute NeighborSet
     * for all match_vertex_[kth] vertex kth > ith, kth >= 1, 0<=ith<n-1
     *
     * each vertex=match_vertex_[ith] can compute VertexSet
     * for all match_vertex_[kth] vertex kth > ith, kth >= 2, 0<=ith<n-1
     *
     * therefore need two list of candidates
     * one for NeighborSet
     * one for VertexSet
     *
     * NeighborSet layout for a query of n vertices
     * n = this->match_vertex_.size()
     * match_vertex_[0] uses the first n-1 slots, starting from ith=0
     * match_vertex_[1] uses n-2 slots, starting from ith=n-1
     * match_vertex_[2] uses n-3 slots, starting from ith=(n-1)+(n-2)
     * ...
     * match_vertex_[n-2] uses 1 slot, starting from ith=(n-1)+...+2
     * match_vertex_[n-1] uses 0 slot.
     *
     * NeighborSet is 2-dimensional because
     * if one query vertex is unconnected
     * then it needs NeighborSet of all edge indices (edge + topology labels)
     *
     * VertexSet layout for a query of n vertices
     * match_vertex_[0] does not use slots
     * match_vertex_[1] uses n-2 slots, starting from ith=0
     * match_vertex_[2] uses n-3 slots, starting from ith=n-2
     * match_vertex_[3] uses n-4 slots, starting from ith=2n-5
     * match_vertex_[4] uses n-5 slots, starting from ith=3n-9
     * ...
     * match_vertex_[n-2] uses 1 slot, starting from ith=(n-2)+...+2
     * match_vertex_[n-1] uses 0 slot
     */
    virtual void InitializeCandidateSet() = 0;

    inline bool IsConnected(const size_t pi, const size_t ci) {
        return this->HasEdge(pi, ci) || this->HasEdge(ci, pi);
    }

    void Match();

    inline bool MatchVertexLabel(const size_t pi, const size_t ci) {
        return this->query_.Label(this->match_vertex_[pi])
                == this->query_.Label(this->match_vertex_[ci]);
    }

    inline size_t NIndex(const vid_t pi, const vid_t ci) const {
        /* return the index of NeighborSet of vertex=match_vertex_[pi]
         * that computes candidate set for vertex=match_vertex_[ci]
         * pi: previous index, ci: current index / child index
         * see NeighborSet layout
         * (0,1)        -> 0
         * (0,2)        -> 1
         * (0,n-1)      -> n-2
         * (1,2)        -> n-1
         * (1,n-1)      -> 2n-4
         * ...
         * (n-2, n-1)   -> n(n-1)/2-1
         *
         * end point is the number of allocated positions
         * not the index of the last item
         * arithmetic progression: find the end point and shift left (minus)
         *
         * first term: n-2, last term: n-2-pi, term: pi+1
         * shift: a linear transformation of ci
         * (0,1)    ci=1,   end point=n-1, index=0  =end point-shift
         * (0,n-1)  ci=n-1, end point=n-1, index=n-2=end point-shift
         * shift=n-ci
         */
        size_t n = this->match_vertex_.size();
        return (2 * n - 2 - pi) * (pi + 1) / 2 - n + ci;
    }

    virtual NeighborSet& NSet(const vid_t, const vid_t) = 0;

    // initialize all NeighborSet for unconnected edges (negation)
    virtual void UpdateNSet(const size_t, const size_t) = 0;

    /* return true if no candidate vertex
     *
     * update VertexSet that can be computed from
     * Graph vertex that matched Query match_vertex_[pi]
     * such VertexSet match Query match_vertex_[kth], kth > pi
     *
     * VertexSet does not compute Union
     * to avoid increasing intermediate results
     *
     * a VertexSet can be computed if there is at least one edge between
     * this->match_vertex_[ith] and this->match_vertex[ci] for ith <= pi
     *
     * this can be checked reversely
     * if this->match_vertex_[pi] and this->match_vertex[ci] connect
     * or
     * if VertexSet computed by this->match_vertex_[pi-1] is not empty
     *
     * whether VertexSet can be computed by DSet or ISet
     * depends on how this->match_vertex_[ith] and this->match_vertex_[pi]
     * connect to this->match_vertex_[ci] respectively
     *
     * size condition can be checked at run-time to allow early terminate
     */
    virtual bool UpdateVSet(const size_t) = 0;

    inline size_t VIndex(const size_t pi, const size_t ci) const {
        /* return the index of VertexSet that is candidate set for
         * vertex=match_vertex_[ci] using NeighborSet of
         * vertex=match_vertex_[kth], kth <= pi
         * pi: previous index, ci: current index / child index
         * see VertexSet layout
         * (1,2)        -> 0
         * (1,3)        -> 1
         * (1,n-1)      -> n-3
         * (2,3)        -> n-2
         * (2,4)        -> n-1
         * (2,n-1)      -> 2n-6
         * (3,4)        -> 2n-7
         * (3,n-1)      -> 3n-12
         * ...
         * (n-2, n-1)   -> (n - 2) * (n - 1) / 2 -1
         *
         * arithmetic progression: find the end point and shift left (minus)
         * first term: n-2, last term: n-1-pi, term=pi
         * pi=1, ci=2, end point=n-2, index=0=end point-shift, shift=n-ci
         * pi=1, ci=n-1, end point=n-2, index=n-3, shift=1=n-ci
         * shift: (n-1-pi) - ci + 1
         */
        size_t n = this->match_vertex_.size();
        return (2 * n - 3 - pi) * pi / 2 - n + ci;
    }
    inline VertexSet& VSet(const size_t pi, const size_t ci) {
        return this->vset_1d_[this->VIndex(pi, ci)];
    }

    const Graph &graph_;
    csr::Query &query_;
    const vid_1d_t &match_vertex_;       // match order of query vertices
    vid_1d_t result_;

    std::vector<VertexSet> vset_1d_;

private:
    inline bool HasEdge(const size_t pi, const size_t ci) {
        auto va = this->match_vertex_[pi];
        auto vb = this->match_vertex_[ci];
        return this->query_.HasEdge(va, vb);
    }

    void Match(const size_t);

    // return true if no candidate vertex
    bool UpdateNSet(const size_t);
};

} // namespace dynamic

} // namespace csr

#endif /* INCLUDE_CSR_DYNAMIC_BASE_HPP_ */
