/*
 * execute.hpp
 *
 *  Created on: 22:45 PM Wednesday Aug 30, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_DYNAMIC_EXECUTE_HPP_
#define INCLUDE_CSR_DYNAMIC_EXECUTE_HPP_

namespace utility {
class Config;
class Logger;
} // namespace utility

namespace csr {

class Graph;

namespace dynamic {

typedef utility::Config Config;
typedef utility::Logger Logger;

// public function
bool ExecuteDynamic(Config &, Graph &, Logger &);

} // namespace dynamic

} // namespace csr

#endif /* INCLUDE_CSR_DYNAMIC_EXECUTE_HPP_ */
