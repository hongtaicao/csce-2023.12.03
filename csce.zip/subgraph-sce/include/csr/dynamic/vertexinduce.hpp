/*
 * vertexinduce.hpp
 *
 *  Created on: 3:22 AM Monday Sep 25, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_DYNAMIC_VERTEXINDUCE_HPP_
#define INCLUDE_CSR_DYNAMIC_VERTEXINDUCE_HPP_

#include "include/csr/dynamic/base.hpp"

namespace csr {

namespace dynamic {

class VertexInduce: public Base {
public:
    VertexInduce(const Graph &graph, csr::Query &query,
            const vid_1d_t &match_vertex)
            : Base(graph, query, match_vertex) {
        this->Match();
    }

private:
    inline const vid_1d_t& AllClusterIndex(const size_t pi, const size_t ci) {
        /* result can be empty if the data graph does not have edges
         * connecting a certain pair of vertex labels
         */
        auto va = this->match_vertex_[pi];
        auto vb = this->match_vertex_[ci];
        return this->query_.AllClusterIndex(va, vb);
    }

    void InitializeCandidateSet() override;

    inline NeighborSet& NSet(const vid_t pi, const vid_t ci) override {
        // return the first of nset_2d_, index=0
        return this->nset_2d_[this->NIndex(pi, ci)][0];
    }
    inline NeighborSet_1d_t& NSet1d(const vid_t pi, const vid_t ci) {
        return this->nset_2d_[this->NIndex(pi, ci)];
    }

    void UpdateNSet(const size_t, const size_t) override;

    // return true if no candidate vertex
    bool UpdateVSet(const size_t) override;

    template<typename T>
    bool UpdateVSet(const size_t, const size_t, const T&);

    std::vector<NeighborSet_1d_t> nset_2d_;
};

template<typename T>
bool VertexInduce::UpdateVSet(const size_t pi, const size_t ci,
        const T &vset_i) {
    /* this->match_vertex_[ith] and this->match_vertex_[ci] connect
     * for this->match_vertex_[pi] NeighborSet
     * ISet
     * DSet
     */
    auto &vset_o = this->VSet(pi, ci);
    if (this->IsConnected(pi, ci)) {
        // ISet, Intersect
        vset_o.ISet(vset_i, this->NSet(pi, ci));
        /* early termination can be added when vset_o is computed
         * vset_o will be used in the future to compute candidate set
         * for this->match_vertex_[ci]
         *
         * if vset_o is already empty, then this->match_vertex_[ci]
         * has no match result
         * therefore should check the next candidate for
         * this->match_vertex_[pi]
         * which means abort the current UpdateVSet
         */
        EarlyTerminateSize0(vset_o);
    } else {
        /* DSet, Difference
         * match_vertex_[pi] and match_vertex[ci] do not connect
         * need to minus all this->match_vertex_[pi] NeighborSet
         */
        const auto &nset_1d = this->NSet1d(pi, ci);
        if (nset_1d.size()) {
            if (this->MatchVertexLabel(pi, ci)) {
                DSet(vset_o, vset_i, this->result_[pi], nset_1d);
            } else {
                DSet(vset_o, vset_i, nset_1d);
            }
            EarlyTerminateSize0(vset_o);
        } else {
            /* no need to exclude NeighborSet of match_vertex_[pi]
             * no-op
             */
            vset_o.size = 0;
            vset_o.Copy(vset_i, 0);
        }
    }
    return false;
}

} // namespace dynamic

} // namespace csr

#endif /* INCLUDE_CSR_DYNAMIC_VERTEXINDUCE_HPP_ */
