/*
 * edgeinduce.hpp
 *
 *  Created on: 6:26 AM Monday Sep 25, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_DYNAMIC_EDGEINDUCE_HPP_
#define INCLUDE_CSR_DYNAMIC_EDGEINDUCE_HPP_

#include "include/csr/dynamic/base.hpp"

namespace csr {

namespace dynamic {

class EdgeInduce: public Base {
public:
    EdgeInduce(const Graph &graph, csr::Query &query,
            const vid_1d_t &match_vertex)
            : Base(graph, query, match_vertex) {
        this->Match();
    }

private:
    void InitializeCandidateSet() override;

    inline NeighborSet& NSet(const vid_t pi, const vid_t ci) override {
        return this->nset_1d_[this->NIndex(pi, ci)];
    }

    inline void UpdateNSet(const size_t, const size_t) override {
        // initialize all NeighborSet for unconnected edges (negation)
        // EdgeInduce does not need this
    }

    // return true if no candidate vertex
    bool UpdateVSet(const size_t) override;

    template<typename T>
    bool UpdateVSet(const size_t, const size_t, const T&);

    std::vector<NeighborSet> nset_1d_;
};

template<typename T>
bool EdgeInduce::UpdateVSet(const size_t pi, const size_t ci,
        const T &vset_i) {
    /* this->match_vertex_[ith] and this->match_vertex_[ci] connect
     * for this->match_vertex_[pi] NeighborSet
     * ISet
     * DSet
     */
    auto &vset_o = this->VSet(pi, ci);
    if (this->IsConnected(pi, ci)) {
        // ISet, Intersect
        vset_o.ISet(vset_i, this->NSet(pi, ci));
        /* early termination can be added when vset_o is computed
         * vset_o will be used in the future to compute candidate set
         * for this->match_vertex_[ci]
         *
         * if vset_o is already empty, then this->match_vertex_[ci]
         * has no match result
         * therefore should check the next candidate for
         * this->match_vertex_[pi]
         * which means abort the current UpdateVSet
         */
        EarlyTerminateSize0(vset_o);
    } else {
        /* DSet, Difference
         * match_vertex_[pi] and match_vertex[ci] do not connect
         * need to minus this->match_vertex_[pi]
         * to make sure match_vertex_[pi] and match_vertex[ci] are different
         */
        if (this->MatchVertexLabel(pi, ci)) {
            vset_o.DSet(vset_i, this->result_[pi]);
            EarlyTerminateSize0(vset_o);
        } else {
            /* no need to exclude match_vertex_[pi]
             * no-op
             */
            vset_o.size = 0;
            vset_o.Copy(vset_i, 0);
        }
    }
    return false;
}

} // namespace dynamic

} // namespace csr

#endif /* INCLUDE_CSR_DYNAMIC_EDGEINDUCE_HPP_ */
