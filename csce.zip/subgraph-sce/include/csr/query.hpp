/*
 * query.hpp
 *
 * csr/codegen/query uses std::string to represent vertices
 * to support code generation
 *
 * csr/query supports run-time execution generation
 * and therefore should uses integer to represent vertices
 *
 * because integers have lower operational overhead than std::string
 *
 *  Created on: 10:26 AM Friday Aug 31, 2023
 *      Author: hongt Hongtai Cao
 */

#ifndef INCLUDE_CSR_QUERY_HPP_
#define INCLUDE_CSR_QUERY_HPP_

#include <string>
#include <unordered_map>

#include "include/common.hpp"

namespace csr {

class Query {
public:
    Query(const std::string&, const std::string&, bool);

    inline const cindex_1d_t& AllClusterIndex(const vid_t va, const vid_t vb) {
        /* used in dynamic/execute.cpp
         *
         * result can be empty if the data graph does not have edges
         * connecting a certain pair of vertex labels
         */
        return this->vplabel_to_cindex_[this->Label(va) + " " + this->Label(vb)];
    }

    inline bool HasEdge(const vid_t va, const vid_t vb) {
        return this->out_edge.count(va) and this->out_edge[va].count(vb);
    }

    inline csize_t Index(const vid_t va, const vid_t vb) {
        /* return the index of graph containing all edges like (va, vb)
         * requirement: a, b are vertices and a->b
         */
        auto str_a = std::to_string(va);
        auto str_b = std::to_string(vb);
        return this->edge_to_cindex_[str_a + " " + str_b];
    }

    inline const std::string& Label(const vid_t vertex) const {
        // used by dynamic/execute.cpp
        return this->vertex_to_label_[vertex];
    }

    inline vid_t VertexCount() const {
        return this->vertex_to_label_.size();
    }

    edge_map_t out_edge;

private:
    // edge is flattened to a 1-dimensional array using ClusterIndex()
    string_index_t edge_to_cindex_;

    string_1d_t vertex_to_label_;
    // for negation, include all edge indices that match vertex pair labels
    std::unordered_map<std::string, cindex_1d_t> vplabel_to_cindex_;
};

} // namespace csr

#endif /* INCLUDE_CSR_QUERY_HPP_ */
