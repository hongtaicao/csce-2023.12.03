/*
 * graph.hpp
 *
 * a template used in optimization to connect various graph implementation
 * provide universal method for optimization
 *
 *  Created on: 12:23 PM Thursday 2023-4-20
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_GRAPH_HPP_
#define INCLUDE_OPTIM_GRAPH_HPP_

#include <string>
#include <unordered_map>

#include "include/common.hpp"
#include "include/edgelist/label.hpp"
#include "include/utility/graph.hpp"

namespace optim {

class Graph {
public:
    virtual ~Graph() {
    }

    /* the number of clusters
     * the number of label combinations (la lb le lt)
     * lt: label of the topology
     */
    inline csize_t ClusterCount() const {
        return this->cluster_size_;
    }

    inline csize_t ClusterIndex(const std::string &cluster_key) {
        // cluster_key = "source_label target_label edge_label topology_label"
        return this->clusterkey_index_[cluster_key];
    }

    /* the number of edges of the given edge label index
     * also the cluster size
     */
    virtual eid_t EdgeCount(const csize_t) const = 0;

    /* used to generate edge_index for non-edge
     * collect all edge label and topology label for a pair of vertex label
     * edge_key = (vertex_label vertex_label edge_label topology_label)
     * the union of edge_key can be used to compute non-edge
     */
    string_1d_t &EdgeTopologyLabel(const std::string &);

    inline bool HasCluster(const std::string &cluster_key) const {
        return this->clusterkey_index_.count(cluster_key);
    }

    vid_t LabelFrequency(const vid_t) const;

    inline vid_t MaxDegree() const {
        return this->max_degree_;
    }

    /* note that a graph store a directed edge in both directions
     * e.g., an edge (va:la) -> (vb:lb) is stored with label_id for both
     * (la lb le ->) and (lb la le <-)
     * therefore OutDegree includes
     * bi-directed neighbor and out-neighbor count
     */
    virtual vid_t OutDegree(const csize_t, const vid_t) const = 0;
    virtual vid_t OutVertex(const csize_t, const vid_t, const vid_t) const = 0;

    // number of root level vertices of the given edge label index
    virtual vid_t RootSize(const csize_t) const = 0;

    // the vertex of the given edge label index and vertex index
    virtual vid_t RootVertex(const csize_t, const vid_t) const = 0;

    inline vid_t VertexSize() const {
        return this->vertex_size_;
    }

    virtual void WriteEdgelistText(const std::string &,
            const std::string &) const = 0;

protected:
    Graph(const std::string &data_file, const std::string &label_file) {
        // read data graph header in binary format
        if (not utility::IsFile(data_file)) {
            PrintLCTX("data file missing: " << data_file);
            PrintLCTX("please create the binary dataset first");
            SystemExit(-1);
        }
        this->in_.open(data_file.c_str(), std::ios::binary);
        // binary data format
        utility::graph::ReadHeaderBinary(this->in_, this->vertex_size_,
                this->max_degree_, this->cluster_size_);
        // read data graph label file
        edgelist::ReadLabelFileText(label_file, this->clusterkey_index_);
    }

    vid_t vertex_size_;
    vid_t max_degree_;
    csize_t cluster_size_;

    std::ifstream in_;

private:
    /* connect Query edge to data graph edge
     * if Query(vlabel vlabel elabel tlabel) in the map, then a match
     */
    string_index_t clusterkey_index_;
    // edge label and topology label indexed by vertex pair label
    str_to_str_1d_t vlabel_to_etlabel_;
};

} // namespace optim

#endif /* INCLUDE_OPTIM_GRAPH_HPP_ */
