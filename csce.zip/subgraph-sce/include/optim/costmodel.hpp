/*
 * costmodel.hpp
 *
 * data graph is always treated as labeled
 * dummy labels are given to unlabeled data graphs
 * therefore data graph is processed into binary and always comes with
 * a label.txt file
 * dummy labels do not impact data graph performance because
 * data graph edges are indexed by EdgeKey
 *
 *  Created on: 9:45 AM Monday 2022-11-07
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_COSTMODEL_HPP_
#define INCLUDE_OPTIM_COSTMODEL_HPP_

#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/optim/type.hpp"
#include "include/utility/config.hpp"

namespace optim {

class Graph;
class Query;

namespace symbreak {

class SymBreak;

}

typedef symbreak::SymBreak SymBreak;

// key is the index of Operand.Query.v_1d, the value of Operand.order
typedef std::vector<double> trie_size_1d_t;
typedef std::unordered_map<std::string, trie_size_1d_t> order_to_size_t;
typedef std::unordered_map<tid_t, order_to_size_t> tid_order_size_t;

// base class for all cost models, for substitution purpose
class CostModel {
public:
    CostModel(Config &, Graph &, Query *, SymBreak &);
    virtual ~CostModel() {
    }

    // delete copy constructor and copy assignment
    CostModel(const CostModel &) = delete;
    CostModel &operator=(const CostModel &) = delete;

    std::string ClusterKey(const vid_t, const vid_t);
    void GetNonEdgeIndex(const vid_t, const vid_t, cindex_1d_t &);

    inline Graph &GetGraph() {
        return this->graph_;
    }

    inline double JoinCost(Expression *expression) {
        if (this->config_.GraphStorageSortTrie()) {
            return this->SortTrieJoinCost(expression);
        }
        // default
        return this->HashTrieJoinCost(expression);
    }

    double SelectCost(Expression *);
    double TransposeCost(Expression *);

    void SetOperandSize(Operand *);

    bool edge_match;

protected:
    virtual void InitializeSizeTable(Operand *, trie_size_1d_t &) = 0;

    double AverageOutNeighborSize(const vid_t, const vid_t);
    double EdgeCount(const vid_t, const vid_t);
    vid_t RootSize(const vid_t, const vid_t);

    double HashTrieJoinCost(Expression *);
    double SortTrieJoinCost(Expression *);
    double ScanCost(Operand *);

    trie_size_1d_t &SizeTable(Operand *);

    Config &config_;
    Graph &graph_;
    SymBreak &symbreak_;

private:
    /* if this is declared as *&, then subclass should also use *&
     * if use * by mistake, then a strange bug -> pointer can be invalid
     * have no idea why declaring as *& always leads to invalid pointer
     */
    Query *query_;                      // not owner

    std::unordered_map<csize_t, double> edge_table_;
    /* for a given Operand and its vertex permutation (order)
     * the expected node count of an order
     * the expected distinct value count in computation
     *
     * the first level key is topology id, type = tid
     * the second level key is permutation of Query.v_1d, type = order_t
     */
    tid_order_size_t size_table_;
};

} // namespace optim

#endif /* INCLUDE_OPTIM_COSTMODEL_HPP_ */
