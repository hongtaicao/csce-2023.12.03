/*
 * ri.hpp
 *
 * most constraint first
 *
 *  Created on: Wednesday 2:40 AM Nov 8, 2023
 *      Author: hongt
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_RI_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_RI_HPP_

#include "include/common.hpp"
#include "include/optim/ordergenerator.hpp"

namespace optim {

class Graph;
class Query;

namespace ordergenerator {

class RI: public OrderGenerator {
public:
    /* can pass reference to subclass of optim::Graph
     * implicit cast will be performed
     */
    RI(Config &, Graph &, Query &);

    inline bool InRange() override {
        return this->in_range_;
    }
    inline void Next() override {
        this->in_range_ = false;
    }

private:
    bool in_range_;
};

} // namespace ordergenerator

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_RI_HPP_ */
