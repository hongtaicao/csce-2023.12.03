/*
 * dag.hpp
 *
 *  Created on: 2:47 PM THursday Nov 9, 2023
 *      Author: hongt
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_DAG_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_DAG_HPP_

#include "include/common.hpp"
#include "include/optim/ordergenerator.hpp"

namespace optim {

class Graph;
class Query;

namespace ordergenerator {

class DAG: public OrderGenerator {
public:
    /* can pass reference to subclass of optim::Graph
     * implicit cast will be performed
     */
    DAG(Config &, Graph &, Query &, const vid_1d_t &);

    inline bool InRange() override {
        return this->in_range_;
    }
    inline void Next() override {
        this->in_range_ = false;
    }

private:
    bool in_range_;
};

} // namespace ordergenerator

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_DAG_HPP_ */
