/*
 * base.hpp
 *
 * this holds query graph edges, labels information
 *
 * Query graph is different in terms of labels.
 * Unlabeled is slightly faster than labeled.
 * both unlabeled and labeled should read data graph label.txt file
 * and map Query edges to data graph edges using label.txt
 *
 *  Created on: 14:01 PM 2022-10-29
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_QUERY_BASE_HPP_
#define INCLUDE_OPTIM_QUERY_BASE_HPP_

#include "include/common.hpp"
#include "include/optim/query.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace query {

class Base: public Query {
public:
    Base(Base *b)
            : Query(b) {
    }
    virtual ~Base() {
    }

    virtual inline size_t Hash(const Query *query) {
        size_t key = 17;
        key = key * 31 + std::hash<size_t>()(query->v_1d.size());
        key = key * 31 + std::hash<size_t>()(query->size_b);
        return key * 31 + std::hash<size_t>()(query->size_s);
    }

    bool IsomorphicTo(Query *, Query *);            // called by Query
    virtual vid_t Label(const vid_t) = 0;
    virtual eid_t Label(const vid_t, const vid_t) = 0;

    // used by base class Query
    edge_map_t out_edge;

protected:
    Base()
            : Query() {
    }
    Base(edge_map_t &, const vid_set_t &);

    // override by Labeled/Unlabeled to deal with both cases
    virtual bool IsomorphicTo(Query *, const vid_t, const vid_t, Query *,
            const vid_t, const vid_t) = 0;

private:
    bool IsomorphicTo(Query *, Query *, const vid_1d_t &);
};

} // namespace query

} // namespace optim

#endif /* INCLUDE_OPTIM_QUERY_BASE_HPP_ */
