/*
 * expression.hpp
 *
 *  Created on: 15:37 PM Friday 2022-11-04
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_EXPRESSION_HPP_
#define INCLUDE_OPTIM_EXPRESSION_HPP_

#include <queue>
#include <vector>

#include "include/optim/operand.hpp"
#include "include/optim/type.hpp"

namespace optim {

class Expression {
public:
    // dummy root Expression
    Expression(Operand *output)
            : cost(0), output(output), parent(nullptr) {
        // need to update this->input and this->cost
    }
    // Join / Rename / Transpose Expression
    Expression(Expression *parent, Operand *output)
            : cost(parent->cost), output(output), parent(parent) {
        // need to update this->input and this->cost
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
    inline void DebugPrintChain(bool) const {
    }
#else
    void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
    inline void DebugPrintChain(bool end_of_line) const {
        this->PrintChain(end_of_line);
    }
#endif

    struct DescCost {
        // descending order of cost value
        inline bool operator()(const Expression *a, const Expression *b) const {
            return a->cost > b->cost;
        }
    };

    inline bool IsComplete() const {
        return this->pending.empty();
    }
    inline bool IsJoin() const {
        return this->input.size() > 1;
    }
    inline bool IsRename() const {
        return this->io_vertex_mapping.empty();
    }
    /* Transpose is the last case, should be checked last
     * (this->input.size() == 1) and (not this->io_vertex_mapping.empty())
     * not (IsJoin() or IsRename())
     */

    void PopPending(operand_1d_t &);
    void PopPendingIsomorphic(operand_1d_t &);
    inline void PushPending(Operand *operand) {
        this->pending.push(operand);
    }

    void PrintChain(bool) const;
    void PrintDetail(bool) const;
    void PushPending(const operand_1d_t &);

    double cost;                // current cost from this to root
    Operand *output;            // shared across Operand
    Expression *parent;         // shared across child expr. link expr
    operand_1d_t input;         // owner

    /* map output operand.order -> list of input operand and order
     * to speedup processing for join, rename, transpose
     * join (input.size() > 1): list of vector (input index, input order, ...)
     * each vector contains information to compute one output vertex
     * that corresponds to the current output order
     * each vector should be parsed as pairs (input index, input order)
     * rename (input.size() == 1): leave as empty
     * transpose (input.size() == 1): list of (input order)
     * each item is a size 1 vector
     * each of size 1 vector contains 1 input order
     */
    std::vector<order_1d_t> io_vertex_mapping;
    // sort in ascending order, top is the end of the queue, the largest
    typedef std::priority_queue<Operand *, operand_1d_t,
            Operand::AscQuerySizeIsomorphism> operand_max_heap_t;
    operand_max_heap_t pending;
};

} // namespace optim

#endif /* INCLUDE_OPTIM_EXPRESSION_HPP_ */
