/*
 * utility.hpp
 *
 *  Created on: Thursday 16:10 PM 2022-10-20
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_UTILITY_HPP_
#define INCLUDE_UTILITY_UTILITY_HPP_

#include <algorithm>
#include <cstdint>
#include <iostream>
#include <string>
#include <sys/stat.h>

#include "include/common.hpp"

namespace utility {

// extern declare but not define
extern uint64_t COUNTER_LOOP_0, COUNTER_LOOP_1, COUNTER_LOOP_2;
extern uint64_t COUNTER_LOOP_3, COUNTER_LOOP_4, COUNTER_LOOP_5;
extern uint64_t COUNTER_LOOP_6, COUNTER_LOOP_7, COUNTER_LOOP_8;
extern uint64_t COUNTER_LOOP_9, COUNTER_LOOP_10, COUNTER_LOOP_11;

#ifdef MEASURE_PERFORMANCE
#define AddOne(x)   (x++)
#else
#define AddOne(x)   (void (0))
#endif

// declaration
inline void SplitDirBase(const std::string &, std::string &, std::string &);

// implementation
template<typename T>
void Ignore(T &&) {
    // https://stackoverflow.com/a/15764679/11193802
}

inline void InitializeLoopCounter() {
    COUNTER_LOOP_0 = 0;
    COUNTER_LOOP_1 = 0;
    COUNTER_LOOP_2 = 0;
    COUNTER_LOOP_3 = 0;
    COUNTER_LOOP_4 = 0;
    COUNTER_LOOP_5 = 0;
    COUNTER_LOOP_6 = 0;
    COUNTER_LOOP_7 = 0;
    COUNTER_LOOP_8 = 0;
    COUNTER_LOOP_9 = 0;
    COUNTER_LOOP_10 = 0;
    COUNTER_LOOP_11 = 0;
}

inline bool IsFile(const std::string &name) {
    struct stat info;
    return (stat(name.c_str(), &info) == 0);
}

std::string Join(const string_1d_t &, const std::string &);

std::string KeepAlNum(const std::string &, const char &);

inline void MkDir(const std::string &directory) {
    /* make directory if not exists
     * https://stackoverflow.com/a/18101042
     */
    struct stat info;
    if (not directory.size()) {
        // skip empty directory
        return;
    }
    if (stat(directory.c_str(), &info) == 0) {
        if (info.st_mode & S_IFDIR) {
            // S_ISDIR() doesn't exist on my windows
            // is directory and it already exists
            return;
        }
        if (info.st_mode & S_IFREG) {
            // is a regular file
            return;
        }
    }
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    mkdir(directory.c_str());
#else
    mkdir(directory.c_str(), 0777);
#endif
    PrintLCTX("create directory: " << directory);
}

/* make directory recursively if not exists
 * https://stackoverflow.com/a/34997986
 * non inline function must be in source file, otherwise multiple definition
 */
void MkRecursiveDir(const std::string &);

inline void MkFileDir(const std::string &file_path) {
    // make directory for file_path if directory does not exist
    std::string directory, basename;
    utility::SplitDirBase(file_path, directory, basename);
    if (directory.size()) {
        utility::MkRecursiveDir(directory);
    }
}

inline void PrintLoopCounter(bool end_of_line) {
    Print("COUNTER_LOOP_0=" << COUNTER_LOOP_0);
    Print(" COUNTER_LOOP_1=" << COUNTER_LOOP_1);
    Print(" COUNTER_LOOP_2=" << COUNTER_LOOP_2);
    Print(" COUNTER_LOOP_3=" << COUNTER_LOOP_3);
    Print(" COUNTER_LOOP_4=" << COUNTER_LOOP_4);
    Print(" COUNTER_LOOP_5=" << COUNTER_LOOP_5);
    Print(" COUNTER_LOOP_6=" << COUNTER_LOOP_6);
    Print(" COUNTER_LOOP_7=" << COUNTER_LOOP_7);
    Print(" COUNTER_LOOP_8=" << COUNTER_LOOP_8);
    Print(" COUNTER_LOOP_9=" << COUNTER_LOOP_9);
    Print(" COUNTER_LOOP_10=" << COUNTER_LOOP_10);
    Print(" COUNTER_LOOP_11=" << COUNTER_LOOP_11);
    if (end_of_line) {
        PrintLine("");
    }
}

std::string Replace(const std::string &, char, char);

string_1d_t Split(const std::string &, const char);

// split a path into dirname and basename
inline void SplitDirBase(const std::string &path, std::string &directory,
        std::string &file) {
    auto found = path.find_last_of("/\\");
    if (found == std::string::npos) {
        directory = "";
        file = path;
    } else {
        directory = path.substr(0, found);
        file = path.substr(found + 1);
    }
}

inline void SplitExt(const std::string &, std::string &, std::string &);
inline void SplitExt(const std::string &path, std::string &name,
        std::string &extension) {
    auto found = path.find_last_of(".");
    name = path.substr(0, found);
    extension = path.substr(found + 1);
}

template<typename map_T, typename container_T>
void SortMapKey(const map_T &map, container_T &keylist) {
    for (const auto &pair : map) {
        keylist.push_back(pair.first);
    }
    std::sort(keylist.begin(), keylist.end());
}

} // namespace utility

#endif /* INCLUDE_UTILITY_UTILITY_HPP_ */
