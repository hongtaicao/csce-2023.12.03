/*
 * graph.hpp
 *
 * file read and write for graphs
 *
 *  Created on: 1:28 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_GRAPH_HPP_
#define INCLUDE_UTILITY_GRAPH_HPP_

#include <fstream>
#include <string>

#include "include/common.hpp"
#include "include/edgelist/graph.hpp"
#include "include/utility/utility.hpp"

namespace utility {

class Config;

namespace graph {

// forward declare
inline void WriteHeaderBinary(std::ofstream &, vid_t, vid_t, vid_t);

inline bool HasBinary(const std::string &data, const std::string &label) {
    return utility::IsFile(data) and utility::IsFile(label);
}

/* https://stackoverflow.com/a/3097811
 * lifetime of objects and their reference
 * object lifetime is as long as the const reference
 * therefore it is safe to use const reference
 */

inline std::ofstream OutBinary(const std::string &bin_file) {
    MkFileDir(bin_file);
    return std::ofstream(bin_file, std::ios::binary | std::ios::out);
}

inline vid_t PrepareBinary(Config &config, std::ofstream &out,
        edge_map_1d_t &edge_map_1d, vid_t &cluster_count) {
    string_index_t clusterkey_index;
    const vid_t vertex_count = edgelist::ReadGraphTextToGraphs(config,
            edge_map_1d, clusterkey_index);
    const auto max_degree = edgelist::MaxDegree(edge_map_1d);
    cluster_count = clusterkey_index.size();
    WriteHeaderBinary(out, vertex_count, max_degree, cluster_count);
    return vertex_count;
}

inline void ReadHeaderBinary(std::ifstream &in, vid_t &vertex_count,
        vid_t &max_degree, vid_t &label_count) {
    in.read(reinterpret_cast<char *>(&vertex_count), sizeof(vertex_count));
    in.read(reinterpret_cast<char *>(&max_degree), sizeof(max_degree));
    in.read(reinterpret_cast<char *>(&label_count), sizeof(label_count));
    DPrintCTX("read vertex_count=" << vertex_count << " max_degree=");
    DPrintLine(max_degree << " label_count=" << label_count);
}

inline void WriteHeaderBinary(std::ofstream &out, vid_t vertex_count,
        vid_t max_degree, vid_t label_count) {
    out.write(reinterpret_cast<char *>(&vertex_count), sizeof(vertex_count));
    out.write(reinterpret_cast<char *>(&max_degree), sizeof(max_degree));
    out.write(reinterpret_cast<char *>(&label_count), sizeof(label_count));
    DPrintCTX("write vertex_count=" << vertex_count << " max_degree=");
    DPrintLine(max_degree << " label_count=" << label_count);
}

} // namespace graph

} // namespace utility

#endif /* INCLUDE_UTILITY_GRAPH_HPP_ */
