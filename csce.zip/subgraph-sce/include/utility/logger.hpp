/*
 * logger.hpp
 *
 * save performance measure variables
 *
 *  Created on: 2:17 AM Thursday 2022-11-10
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_LOGGER_HPP_
#define INCLUDE_UTILITY_LOGGER_HPP_

#include <cstdlib>          // size_t
#include <string>
#include <unordered_map>

#include "include/utility/utility.hpp"

namespace utility {

class Logger {
    typedef std::unordered_map<std::string, std::string> data_t;
public:
    Logger() {
        this->AliasCount = 0;
        this->SkipVertexCount = 0;
        this->SkipVertexCountBeforeIEP = 0;
        this->SkipVertexFirstIndex = 0;

        this->BranchPrunedCount = 0;
        this->BranchTotalCount = 0;
        this->CostMargin = 0;
        this->MatchVertex = "";
        this->MultipleCompletePlan = false;
        this->PlanCount = 0;
        this->PlanCost = 0;
        this->PoolInitialSize = 0;
        this->PoolRemainSize = 0;
        this->SymbreakScore = -1;

        this->DurationBuildOne = 0.0;
        this->DurationInitialPool = 0.0;
        this->DurationOrderGenerate = 0.0;
        this->DurationSymbreakOne = 0.0;

        this->DurationExecutionCompile = 0.0;
        this->DurationExecutionDynamic = 0.0;
        this->DurationReadBinaryGraph = 0.0;

        this->AutomorphismCount = 0;
        this->InclusionEclusionCount = 0;
        this->IntersectSizeOptimizeCount = 0;
        this->MatchCount = 0;
        this->SymbreakCount = 0;
    }

    inline data_t Data() const {
        data_t data;
        data["AliasCount"] = std::to_string(this->AliasCount);
        data["SkipVertexCount"] = std::to_string(this->SkipVertexCount);
        data["SkipVertexCountBeforeIEP"] = std::to_string(
                this->SkipVertexCountBeforeIEP);
        data["SkipVertexFirstIndex"] = std::to_string(
                this->SkipVertexFirstIndex);

        data["BranchPrunedCount"] = std::to_string(this->BranchPrunedCount);
        data["BranchTotalCount"] = std::to_string(this->BranchTotalCount);
        data["CostMargin"] = std::to_string(this->CostMargin);
        data["MatchVertex"] = utility::Replace(this->MatchVertex, ',', ' ');
        data["MultipleCompletePlan(bool)"] = std::to_string(
                this->MultipleCompletePlan);
        data["PlanCount"] = std::to_string(this->PlanCount);
        data["PlanCost"] = std::to_string(this->PlanCost);
        data["PoolInitialSize"] = std::to_string(this->PoolInitialSize);
        data["PoolRemainSize"] = std::to_string(this->PoolRemainSize);
        data["SymbreakScore"] = std::to_string(this->SymbreakScore);

        data["DurationBuildOne(s)"] = std::to_string(this->DurationBuildOne);
        data["DurationInitialPool(s)"] = std::to_string(
                this->DurationInitialPool);
        data["DurationOrderGenerate(s)"] = std::to_string(
                this->DurationOrderGenerate);
        data["DurationSymbreakOne(s)"] = std::to_string(
                this->DurationSymbreakOne);

        data["DurationExecutionCompile(s)"] = std::to_string(
                this->DurationExecutionCompile);
        data["DurationExecutionDynamic(s)"] = std::to_string(
                this->DurationExecutionDynamic);
        data["DurationReadBinaryGraph(s)"] = std::to_string(
                this->DurationReadBinaryGraph);

        data["AutomorphismCount"] = std::to_string(this->AutomorphismCount);
        data["InclusionEclusionCount"] = std::to_string(
                this->InclusionEclusionCount);
        data["IntersectSizeOptimizeCount"] = std::to_string(
                IntersectSizeOptimizeCount);
        data["MatchCount"] = std::to_string(this->MatchCount);
        data["SymbreakCount"] = std::to_string(this->SymbreakCount);
        return data;
    }

    // codegen
    size_t AliasCount;              // the number of dummy set operations
    size_t SkipVertexCount;         // vertex mapping does not matter
    size_t SkipVertexCountBeforeIEP;
    size_t SkipVertexFirstIndex;    // first index whose mapping not matter

    // top-down optimization
    size_t BranchPrunedCount;
    size_t BranchTotalCount;
    double CostMargin;
    std::string MatchVertex;        // query vertex matching order
    bool MultipleCompletePlan;      // whether multiple complete plan in pool
    size_t PlanCount;               // total number of plans for a query
    double PlanCost;                // the best plan cost
    size_t PoolInitialSize;
    size_t PoolRemainSize;
    double SymbreakScore;           // the best plan score

    // time used in top-down optimization computation
    double DurationBuildOne;        // build the first Expression
    double DurationInitialPool;     // build the initial pool
    double DurationOrderGenerate;   // build the match vertex order
    double DurationSymbreakOne;     // symmetry breaking for first Expression

    // time used in execution
    double DurationExecutionCompile;
    double DurationExecutionDynamic;
    double DurationReadBinaryGraph;

    // count metric
    size_t AutomorphismCount;
    /* see csr/codegen/statement
     * the number of vertices computed through inclusion-exclusion principle
     * the principle is useful when the number of vertices > 1
     */
    size_t InclusionEclusionCount;
    /* see csr/codegen/statement
     * the number of Set Intersection replaced by Set IntersectSize
     * due to skipping computing set elements to get set size
     */
    size_t IntersectSizeOptimizeCount;
    uint64_t MatchCount;            // number of results
    size_t SymbreakCount;
};

} // namespace utility

#endif /* INCLUDE_UTILITY_LOGGER_HPP_ */
