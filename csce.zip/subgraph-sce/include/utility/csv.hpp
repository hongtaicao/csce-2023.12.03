/*
 * csv.hpp
 *
 *  Created on: 8:56 AM Sunday 2023-2-26
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_CSV_HPP_
#define INCLUDE_UTILITY_CSV_HPP_

#include <string>
#include <vector>

namespace utility {

// https://stackoverflow.com/a/30338543

enum class CSVState {
    UnquotedField, QuotedField, QuotedQuote
};

std::vector<std::vector<std::string>> ReadCSV(const std::string &);
std::vector<std::string> ReadCSVRow(const std::string &);

} // namespace utility

#endif /* INCLUDE_UTILITY_CSV_HPP_ */
