/*
 * config.hpp
 *
 * parse the command line input
 * hard code all configuration flags to prevent key mismatch at run-time
 *
 * configuration level
 * GraphStorage: CSR, SortTrie
 *  +-- Algorithm: AutoMine, Ours
 *      +-- QueryName
 *
 *  Created on: 0:07 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_CONFIG_HPP_
#define INCLUDE_UTILITY_CONFIG_HPP_

#include <sstream>
#include <string>
#include <unordered_map>

#include "include/common.hpp"

namespace utility {

class Logger;

class Config {
public:
    Config(int argc, char *argv[]);

    void SaveToFile(const Logger &);

    // configuration function
    inline const std::string &Algorithm() {
        return this->string_[Config::KeyAlgorithm];
    }
    inline bool AlgorithmAdhoc() {
        return this->Algorithm() == Config::ValueAdhoc;
    }
    inline bool AlgorithmWCOJ() {
        // worst-case optimal join
        return this->Algorithm() == Config::ValueWCOJ;
    }
    inline bool AlgorithmTopDown() {
        return this->Algorithm() == Config::ValueTopDown;
    }
    inline const std::string &BinaryDirectory() {
        return this->string_[Config::KeyBinaryDirectory];
    }
    inline std::string BinaryGraph() {
        const std::string &storage = this->GraphStorage();
        return this->BinaryDirectory() + "/graph." + storage + ".bin";
    }
    inline const std::string &CompilerOutputMode() {
        return this->string_[Config::KeyCompilerOutputMode];
    }
    inline bool CompilerOutputModeAppend() {
        return this->string_[Config::KeyCompilerOutputMode]
                == Config::ValueAppend;
    }
    inline bool CompilerOutputModeCleanAppend() {
        return this->string_[Config::KeyCompilerOutputMode]
                == Config::ValueCleanAppend;
    }
    inline bool CompilerOutputModeCleanSort() {
        return this->string_[Config::KeyCompilerOutputMode]
                == Config::ValueCleanSort;
    }
    inline bool CompilerOutputModeSort() {
        return this->string_[Config::KeyCompilerOutputMode]
                == Config::ValueSort;
    }
    inline bool CostModelHyperGeometry() {
        return this->string_[Config::KeyCostModel] == Config::ValueHyperGeometry;
    }
    inline bool CostModelPowerLaw() {
        return this->string_[Config::KeyCostModel] == Config::ValuePowerLaw;
    }
    inline const std::string &DataFile() {
        return this->string_[Config::KeyDataFile];
    }
    inline const std::string &DateTime() {
        return this->string_[Config::KeyDateTime];
    }
    inline bool EncodeVariable() {
        // whether encode variable name in codegen
        return this->int_[Config::KeyEncodeVariable];
    }
    inline bool EstimateCost() {
        // if plan (-p) and query (-q) are both given
        return this->Plan().size()
                and this->string_[Config::KeyQueryFile].size();
    }
    inline bool ExecuteCompile() {
        return this->string_[Config::KeyExecute] == Config::ValueCompile;
    }
    const std::string &FunctionName();
    inline const std::string &GraphStorage() {
        return this->string_[Config::KeyGraphStorage];
    }
    inline bool GraphStorageCSR() {
        return this->GraphStorageCSR0() or this->GraphStorageCSR1();
    }
    inline bool GraphStorageCSR0() {
        return this->GraphStorage() == Config::ValueCSR0;
    }
    inline bool GraphStorageCSR1() {
        return this->GraphStorage() == Config::ValueCSR1;
    }
    inline bool GraphStorageSortTrie() {
        return this->GraphStorage() == Config::ValueSortTrie;
    }
    inline bool IEPAlgorithmGraphPi() {
        return this->string_[Config::KeyIEPAlgorithm]
                == Config::ValueGraphPi;
    }
    inline bool IEPAlgorithmTransitivity() {
        return this->string_[Config::KeyIEPAlgorithm]
                == Config::ValueTransitivity;
    }
    inline bool IEPCommonSet() {
        // the same set may appear multiple times in set intersection
        return this->int_[Config::KeyIEPCommonSet];
    }
    inline bool IEPIntersectDP() {
        /* due to the nature of inclusion-exclusion principle
         * dynamic programming opportunity always exists, 3 or more sets
         */
        return this->int_[Config::KeyIEPIntersectDP];
    }
    inline bool IEPIntersectSize() {
        // comes with inclusion-exclusion principle dynamic programming
        return this->int_[Config::KeyIEPIntersectSize];
    }
    inline size_t IEPSize() {
        return this->int_[Config::KeyIEPSize];
    }
    inline size_t IndentSize() {
        return this->int_[Config::KeyIndentSize];
    }
    inline bool IsLabeled() {
        return this->int_[Config::KeyIsLabeled];
    }
    inline bool IsomorphismEdgeInduce() {
        // non-induced, does not preserve edge absence
        return this->string_[Config::KeyIsomorphism] == Config::ValueEdgeInduce;
    }
    inline bool IsomorphismHomomorphism() {
        return this->string_[Config::KeyIsomorphism]
                == Config::ValueHomomorphism;
    }
    inline bool IsomorphismVertexInduce() {
        // induced, preserve edge absence
        return this->string_[Config::KeyIsomorphism]
                == Config::ValueVertexInduce;
    }
    inline const std::string &LabelFile() {
        return this->string_[Config::KeyLabelFile];
    }
    inline bool OperandSizeTable() {
        return this->string_[Config::KeyOperandSize] == Config::ValueTable;
    }
    inline bool OperandSizeTrie() {
        return this->string_[Config::KeyOperandSize] == Config::ValueTrie;
    }
    inline bool Optimize() {
        // if plan is not given
        return this->string_[Config::KeyPlan].empty();
    }
    inline const std::string &OrderGenerator() {
        return this->string_[Config::KeyOrderGenerator];
    }
    inline bool OrderGeneratorAddDAG() {
        return this->string_[Config::KeyOrderGeneratorAdd] == Config::ValueDAG;
    }
    inline bool OrderGeneratorAdhoc() {
        return this->OrderGenerator() == Config::ValueAdhoc;
    }
    inline bool OrderGeneratorDegreeLabel() {
        return this->OrderGenerator() == Config::ValueDegreeLabel;
    }
    inline bool OrderGeneratorNonAutomorphism() {
        return this->OrderGenerator() == Config::ValueNonAutomorphism;
    }
    inline bool OrderGeneratorRI() {
        /* RI match vertex: match as many pattern edges as possible
         * add the 4th rule using data graph label information
         * lower match order of pattern vertices
         * if they do not matter other vertex candidates
         */
        return this->OrderGenerator() == Config::ValueRI;
    }
    inline bool OrderGeneratorRIDataGraph() {
        /* an improved version of RI by using the datApproxa graph
         */
        return this->OrderGenerator() == Config::ValueRIDataGraph;
    }
    inline bool OrderGeneratorRIImplement() {
        /* an improved version of RI by using the data graph
         */
        return this->OrderGenerator() == Config::ValueRIImplement;
    }
    inline const std::string &Plan() {
        // Plan.getter
        return this->string_[Config::KeyPlan];
    }
    inline void Plan(const std::string &plan) {
        // Plan.setter
        this->string_[Config::KeyPlan] = plan;
    }
    inline bool Polynomial2006() {
        /* a combination
         * common subexpression elimination
         * algebraic factorization
         */
        return this->int_[Config::KeyPolynomial2006];
    }
    inline bool Polynomial2006DP() {
        return this->int_[Config::KeyPolynomial2006DP];
    }
    inline const std::string &QueryFile() {
        return this->string_[Config::KeyQueryFile];
    }
    inline const std::string &QueryName() {
        // QueryName.getter
        return this->string_[Config::KeyQueryName];
    }
    inline void QueryName(const std::string &query_name) {
        // QueryName.setter
        this->string_[Config::KeyQueryName] = query_name;
    }
    inline bool ReadMinimalData() {
        return this->int_[Config::KeyReadMinimalData];
    }
    inline size_t SampleCount() {
        return this->int_[Config::KeySampleCount];
    }
    inline bool SampleInducedSubgraph() {
        return this->int_[Config::KeySampleInducedSubgraph];
    }
    inline int SampleRetryCount() {
        return this->int_[Config::KeySampleRetryCount];
    }
    inline size_t SampleSubgraphSize() {
        return this->int_[Config::KeySampleSubgraphSize];
    }
    inline const std::string &SaveFile() {
        // if return "", don't save to file
        return this->string_[Config::KeySaveFile];
    }
    inline std::string &SaveIntermediateFile() {
        return this->string_[Config::KeySaveIntermediateFile];
    }
    inline std::string SaveIntermediateFile(void *suffix) {
        /* https://stackoverflow.com/a/7850160
         * turn an address to string
         */
        std::stringstream ss;
        ss << "-" << suffix << ".txt";
        std::string name(ss.str());
        return this->string_[Config::KeySaveIntermediateFile] + name;
    }
    inline bool ShareSubquery() {
        return this->int_[Config::KeyShareSubquery];
    }
    inline const std::string &String(const std::string &key) {
        return this->string_[key];
    }
    inline bool SymmetryBreaking2007() {
        return this->string_[Config::KeySymmetryBreaking]
                == Config::ValueSymBreak2007;
    }
    inline bool SymmetryBreakingDisable() {
        return this->string_[Config::KeySymmetryBreaking].empty();
    }
    inline bool SymmetryBreakingGraphPi() {
        return this->string_[Config::KeySymmetryBreaking]
                == Config::ValueSymBreakGraphPi;
    }

    /* constant for argument key value pairs
     * error: 'const string {aka const std::basic_string<char>}' cannot be
     * the type of a complete constant expression because it has
     * mutable sub-objects
     *
     * https://stackoverflow.com/a/1563906
     * declare here, and define in implementation file
     */
    const static std::string KeyAlgorithm;
    const static std::string KeyAutomorphism;
    const static std::string KeyBinaryDirectory;
    const static std::string KeyCompilerOutputMode;
    const static std::string KeyCostModel;
    const static std::string KeyDataFile;
    const static std::string KeyDateTime;
    const static std::string KeyEncodeVariable;
    const static std::string KeyExecute;
    const static std::string KeyFunctionName;
    const static std::string KeyGraphStorage;
    const static std::string KeyIEPAlgorithm;
    const static std::string KeyIEPCommonSet;
    const static std::string KeyIEPIntersectDP;
    const static std::string KeyIEPIntersectSize;
    const static std::string KeyIEPSize;
    const static std::string KeyIndentSize;
    const static std::string KeyIsLabeled;
    const static std::string KeyIsomorphism;
    const static std::string KeyLabelFile;
    const static std::string KeyOperandSize;
    const static std::string KeyOrderGenerator;
    const static std::string KeyOrderGeneratorAdd;
    const static std::string KeyPlan;
    const static std::string KeyPolynomial2006;
    const static std::string KeyPolynomial2006DP;
    const static std::string KeyQueryFile;
    const static std::string KeyQueryName;
    const static std::string KeyReadMinimalData;
    const static std::string KeySampleCount;
    const static std::string KeySampleInducedSubgraph;
    const static std::string KeySampleRetryCount;
    const static std::string KeySampleSubgraphSize;
    const static std::string KeySaveFile;
    const static std::string KeySaveIntermediateFile;
    const static std::string KeyShareSubquery;
    const static std::string KeySymmetryBreaking;
    const static std::string KeyVersion;
    const static std::string ValueAdhoc;
    const static std::string ValueAppend;
    const static std::string ValueCSR0;
    const static std::string ValueCSR1;
    const static std::string ValueCleanAppend;
    const static std::string ValueCleanSort;
    const static std::string ValueCompile;
    const static std::string ValueDAG;
    const static std::string ValueDataQuery;
    const static std::string ValueDataQueryDateTime;
    const static std::string ValueDegreeLabel;
    const static std::string ValueEdgeInduce;
    const static std::string ValueGraphPi;
    const static std::string ValueHomomorphism;
    const static std::string ValueHyperGeometry;
    const static std::string ValueNonAutomorphism;
    const static std::string ValuePowerLaw;
    const static std::string ValueRI;
    const static std::string ValueRIDataGraph;
    const static std::string ValueRIImplement;
    const static std::string ValueSingleDirect;
    const static std::string ValueSort;
    const static std::string ValueSortTrie;
    const static std::string ValueSymBreak2007;
    const static std::string ValueSymBreakGraphPi;
    const static std::string ValueTable;
    const static std::string ValueTopDown;
    const static std::string ValueTransitivity;
    const static std::string ValueTrie;
    const static std::string ValueVersion;
    const static std::string ValueVersionDataQuery;
    const static std::string ValueVersionDataQueryDateTime;
    const static std::string ValueVertexInduce;
    const static std::string ValueWCOJ;

    // other constant variable
    const static std::string FUNCTION_FILE;
    const static std::string LOG_FILE;

private:
    void DefaultHeader(string_1d_t &) const;
    void PrintParsedArgument();
    void SetOutFileName(const std::string &, const std::string &,
            const std::string &, const std::string &);

    /*
     * https://stackoverflow.com/a/70447240
     * std::unordered_map<std::string const, std::string> uses
     * std::hash<std::string const>, but no specialization exists for
     * hash<std::string const>
     */
    std::unordered_map<std::string, int> int_;
    std::unordered_map<std::string, std::string> string_;
};

} // namespace utility

#endif /* INCLUDE_UTILITY_CONFIG_HPP_ */
