/*
 * algorithm.cpp
 *
 *  Created on: 8:11 AM Thursday, Aug 10, 2023
 *      Author: hongt Hongtai Cao
 */

#include "include/algorithm/algorithm.hpp"

namespace algorithm {

size_t Permute(size_t n, size_t k) {
    size_t result = 1;
    while (k > 0) {
        result *= n;
        n--;
        k--;
    }
    return result;
}

} // algorithm
