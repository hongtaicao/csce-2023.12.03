/*
 * combination.cpp
 *
 *  Created on: 14:08 PM Sunday 2022-11-06
 *      Author: Hongtai Cao
 */

#include "include/algorithm/combination.hpp"
#include "include/common.hpp"

namespace algorithm {

void Combination::Next() {
    for (size_t index = this->size_; index > 0;) {
        index--;
        this->data_[index]++;
        /* check if a combination is feasible
         * each combination is presented in ascending order
         * each element is at least 1 more than the one before it
         * the last element can have a max value = this->n_ - 1
         * which is the element at index = this.size_ - 1
         * then index = 0 can have a max value
         * (this->n_ - 1) - (this.size_ - 1) = this->n_ - this->size_
         * then the linear function that maps between index and its value
         * data[index] <= index + n_ - size_
         */
        if (this->data_[index] < index + this->offset_) {
            // find a valid combination
            for (index++; index < this->size_; index++) {
                this->data_[index] = this->data_[index - 1] + 1;
            }
            return;
        }
        /* the current pointer is out of range
         * adjust its previous pointer
         */
    }
    this->in_range_ = false;
}

void Combination::PrintDetail(bool end_of_line) const {
    PrintArray(this->data_, this->Size());
    if (end_of_line) {
        PrintLine("");
    }
}

Combination::choice_t Combination::ToSet() const {
    choice_t choice;
    choice.reserve(this->size_);
    for (size_t index = 0; index < this->size_; index++) {
        choice.insert(this->data_[index]);
    }
    return choice;
}

Combination::Combination(const size_t n, size_t k)
        : offset_(n - k + 1), size_(k) {
    // n choose k
    if ((k > 0) and (n >= k)) {
        this->data_ = new size_t[k];
        for (k = 0; k < this->size_; k++) {
            this->data_[k] = k;
        }
        this->in_range_ = true;
    } else {
        // note this->n_ and this->k_ can overflow and can be invalid
        this->data_ = nullptr;
        this->in_range_ = false;
    }
}

}
