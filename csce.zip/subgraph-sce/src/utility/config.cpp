/*
 * config.cpp
 *
 *  Created on: 0:10 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include <algorithm>        // std::min, std::sort
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <utility>          // std::move
#include <vector>

#include "include/common.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/csv.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace utility {

namespace config {

int GetInt(int argc, char *argv[], int &i) {
    i++;
    if (i < argc) {
        return std::stoi(argv[i]);
    } else {
        const std::string key(argv[i - 1]);
        PrintLCTX("missing string value for key [" << key << "]");
        SystemExit(-1);
    }
    return 0;
}

std::string GetString(int argc, char *argv[], int &i) {
    i++;
    if (i < argc) {
        return std::string(argv[i]);
    } else {
        const std::string key(argv[i - 1]);
        PrintLCTX("missing string value for key [" << key << "]");
        SystemExit(-1);
    }
    return "";
}

inline void IsFile(const std::string &key, const std::string &value) {
    if (not utility::IsFile(value)) {
        PrintLCTX("file does not exist [" << key << "=" << value << ']');
        SystemExit(-1);
    }
}

} // namespace config

void Config::DefaultHeader(string_1d_t &header) const {
    header.clear();
    Logger logger;
    auto log_data = logger.Data();
    for (auto &pair : log_data) {
        header.push_back(pair.first);
    }
    for (auto &pair : this->int_) {
        header.push_back(pair.first);
    }
    for (auto &pair : this->string_) {
        header.push_back(pair.first);
    }
    std::sort(header.begin(), header.end());
}

const std::string& Config::FunctionName() {
    if (not this->string_.count(Config::KeyFunctionName)) {
        // build function name
#if !defined(COUNTING) and defined(LISTING)
        // LISTING
        std::string func_name("L");
#elif !defined(COUNTING) and defined(MEMORY)
        std::string func_name("M");
#else
        // default COUNTING
        std::string func_name("C");
#endif
        if (this->IsomorphismEdgeInduce()) {
            // EdgeInduced, does not preserve absence of edges
            func_name += "E_";
        } else if (this->IsomorphismHomomorphism()) {
            // homomorphism, does not require pair-wise different
            func_name += "H_";
        } else {
            // VertexInduced, preserve absence of edges
            func_name += "V_";
        }
        const size_t min_length = std::min(this->DataFile().size(),
                this->QueryFile().size());
        size_t pos = 0;
        for (size_t index = 0; index < min_length; index++) {
            const char &ch = this->DataFile()[index];
            if (ch != this->QueryFile()[index]) {
                break;
            } else if ((ch == '/') or (ch == '\\')) {
                pos = index + 1;
            }
        }
        std::string filename, extension;
        // get data file names
        SplitExt(this->DataFile().substr(pos), filename, extension);
        // filter invalid symbols
        func_name += utility::KeepAlNum(filename, '_');
        func_name += "_";
        // get query file name
        SplitExt(this->QueryFile().substr(pos), filename, extension);
        func_name += utility::KeepAlNum(filename, '_');
        if (this->OrderGeneratorRI() or this->OrderGeneratorRIImplement()
                or this->OrderGeneratorRIDataGraph()) {
            func_name += ("_" + this->OrderGenerator());
        }
        if (this->string_[Config::KeyOrderGeneratorAdd].size()) {
            func_name += ("_" + this->string_[Config::KeyOrderGeneratorAdd]);
        }
#ifdef COUNTING
        // add related plan generation flag
        if (this->Polynomial2006()) {
            func_name += "_p2006";
        }
#endif
        this->string_[Config::KeyFunctionName] = std::move(func_name);
    }
    return this->string_[Config::KeyFunctionName];
}

void Config::SaveToFile(const Logger &logger) {
    // save Config and Logger to LOG_FILE
    string_1d_t header;
    if (utility::IsFile(this->LOG_FILE)) {
        // read header from LOG_FILE
        std::ifstream infile(this->LOG_FILE);
        std::string line;
        std::getline(infile, line);
        header = ReadCSVRow(line);
        if (header.size() == 1 and header[0].empty()) {
            header.clear();
        }
    }
    if (header.empty()) {
        this->DefaultHeader(header);
        utility::MkFileDir(this->LOG_FILE);
        std::ofstream outfile(this->LOG_FILE);  // default std::ios::trunc
        for (size_t ith = 0; ith < header.size(); ith++) {
            if (ith + 1 == header.size()) {
                outfile << header[ith];
            } else {
                outfile << header[ith] << ",";
            }
        }
        outfile << std::endl;
        PrintLCTX("create result summary file=" << this->LOG_FILE);
    }
    // fill in row
    string_1d_t row;
    row.reserve(header.size());
    auto log_data = logger.Data();
    for (auto &key : header) {
        if (log_data.count(key)) {
            row.push_back(log_data[key]);
        } else if (this->int_.count(key)) {
            row.push_back(std::to_string(this->int_[key]));
        } else if (this->string_.count(key)) {
            row.push_back(utility::Replace(this->string_[key], ',', ' '));
        } else {
            row.push_back("");
        }
        row.push_back(",");
    }
    // append log file
    if (row.size()) {
        // remove the trailing ,
        row.pop_back();
        // append logger file
        utility::MkFileDir(this->LOG_FILE);
        std::ofstream outfile(this->LOG_FILE, std::ios::app);
        for (auto &item : row) {
            outfile << item;
        }
        outfile << std::endl;
        PrintLCTX("append result summary file=" << this->LOG_FILE);
    }
}

void Config::SetOutFileName(const std::string &key, const std::string &dataset,
        const std::string &query_name, const std::string &suffix) {
    // override Config::KeySaveFile
    if (this->string_[key] == Config::ValueDataQuery) {
        this->string_[key] = dataset + "-" + query_name + suffix;
    } else if (this->string_[key] == Config::ValueDataQueryDateTime) {
        std::string date_time = utility::Replace(__DATE__, ' ', '_') + "-";
        date_time += utility::Replace(__TIME__, ':', '_');
        this->string_[key] = dataset + "-" + query_name + "-" + date_time
                + suffix;
    } else if (this->string_[key] == Config::ValueVersionDataQuery) {
        this->string_[key] = Config::ValueVersion + "-" + dataset + "-"
                + query_name + suffix;
    } else if (this->string_[key] == Config::ValueVersionDataQueryDateTime) {
        std::string date_time = utility::Replace(__DATE__, ' ', '_') + "-";
        date_time += utility::Replace(__TIME__, ':', '_');
        this->string_[key] = Config::ValueVersion + "-" + dataset + "-"
                + query_name + "-" + date_time + suffix;
    }
}

Config::Config(int argc, char *argv[]) {
    this->string_[Config::KeyDateTime] = GetCurrentTime();
    // set default values
    this->int_[Config::KeyAutomorphism] = 0;    // don't include automorphism
    this->int_[Config::KeyEncodeVariable] = 1;
    this->int_[Config::KeyIndentSize] = 2;
    this->int_[Config::KeyIsLabeled] = 1;
    this->int_[Config::KeyIEPCommonSet] = 1;        // enable optimize
    this->int_[Config::KeyIEPIntersectDP] = 1;      // enable optimize
    this->int_[Config::KeyIEPIntersectSize] = 1;    // enable optimize
    this->int_[Config::KeyIEPSize] = 4;             // max support 4
    this->int_[Config::KeyPolynomial2006] = 1;      // enable the algorithm
    this->int_[Config::KeyPolynomial2006DP] = 1;    // enable optimize
    this->int_[Config::KeyReadMinimalData] = 1;
    this->int_[Config::KeySampleCount] = 100;
    this->int_[Config::KeySampleRetryCount] = 100;
    this->int_[Config::KeySampleSubgraphSize] = 6;
    this->int_[Config::KeyShareSubquery] = 1;       // enable sharing
    this->string_[Config::KeyAlgorithm] = Config::ValueWCOJ;
    this->string_[Config::KeyCompilerOutputMode] = Config::ValueAppend;
    this->string_[Config::KeyCostModel] = Config::ValueHyperGeometry;
    this->string_[Config::KeyExecute] = Config::ValueCompile;
    this->string_[Config::KeyGraphStorage] = Config::ValueCSR1;
    this->string_[Config::KeyIEPAlgorithm] = Config::ValueGraphPi;
    this->string_[Config::KeyIsomorphism] = Config::ValueVertexInduce;
    this->string_[Config::KeyOperandSize] = Config::ValueTrie;
    // for IEPSize=k, GraphPi complexity is 2^(k choose 2)
    this->string_[Config::KeyOrderGenerator] = Config::ValueRIDataGraph;
    // improve the original paper with dynamic programming
    this->string_[Config::KeySymmetryBreaking] = Config::ValueSymBreak2007;
    this->string_[Config::KeyVersion] = Config::ValueVersion;
    // argv_[0]: program name
    // argv_[1]: first argument
    for (int i = 1; i < argc; i++) {
        const std::string key(argv[i]);
        if (key == this->KeyAlgorithm) {
            // data graph, need processing
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyAutomorphism) {
            // include automorphic subgraphs
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyBinaryDirectory) {
            // data graph directory, post processing folder
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyCompilerOutputMode) {
            // how to compile functions, see csr::codegen::Writer
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyCostModel) {
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyDataFile) {
            // text data graph, need processing, cannot be empty
            this->string_[key] = config::GetString(argc, argv, i);
            config::IsFile(key, this->string_[key]);
        } else if (key == Config::KeyEncodeVariable) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyExecute) {
            // execute name on the data graph
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyGraphStorage) {
            // name for data graph format
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyIEPAlgorithm) {
            /* inclusion-exclusion principle algorithm
             * for IEP size = k
             * GraphPi: complexity is 2^(k choose 2)
             * Transitivity: complexity is 2^k
             */
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyIEPCommonSet) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIEPIntersectDP) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIEPIntersectSize) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIEPSize) {
            /* the max size of inclusion-exclusion principle
             * if < 2, then disable
             * see csr/codegen/statement
             */
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIndentSize) {
            // the indent size, see csr/codegen/statement
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIsLabeled) {
            // labeled data and query graphs
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyIsomorphism) {
            // EdgeInduced, Homomorphism or VertexInduced
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyOperandSize) {
            // Table/Trie to estimate the result size
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyOrderGenerator) {
            // algorithm name to generate vertex order
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyOrderGeneratorAdd) {
            // algorithm name to generate vertex order
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyPlan) {
            // plan, optional
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyPolynomial2006) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyPolynomial2006DP) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyQueryFile) {
            // query / pattern graph
            this->string_[key] = config::GetString(argc, argv, i);
            config::IsFile(key, this->string_[key]);
        } else if (key == Config::KeyQueryName) {
            // query / pattern graph by name
            // used in AutoMine
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyReadMinimalData) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleCount) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleInducedSubgraph) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleRetryCount) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleSubgraphSize) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySaveFile) {
            /* output subgraph in a file. file can be "default"
             * output subgraph count is always provided
             */
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeySaveIntermediateFile) {
            /* output subgraph in a file. file can be "default"
             * output subgraph count is always provided
             */
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == this->KeyShareSubquery) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySymmetryBreaking) {
            this->string_[key] = config::GetString(argc, argv, i);
        } else {
            PrintLCTX("ignore argument [" << key << "]");
        }
    }
    // check necessary parameters
    config::IsFile(Config::KeyDataFile, this->DataFile());
    // set default parameters
    std::string directory;
    std::string file, dataset, extension;
    SplitDirBase(this->DataFile(), directory, file);
    SplitExt(file, dataset, extension);
    if (not this->BinaryDirectory().size()) {
        if (directory.size()) {
            directory += "/";
        } else {
            directory = "./";
        }
        if (dataset.size()) {
            directory += dataset;
        } else {
            directory += extension;
        }
        this->string_[Config::KeyBinaryDirectory] = directory;
    }
    this->string_[Config::KeyLabelFile] = this->BinaryDirectory()
            + "/label.txt";
    std::string query_name;
    if (this->QueryName().size()) {
        query_name = this->QueryName();
    } else {
        SplitDirBase(this->QueryFile(), directory, file);
        SplitExt(file, query_name, extension);
    }
    this->SetOutFileName(Config::KeySaveFile, dataset, query_name, ".txt");
    this->SetOutFileName(Config::KeySaveIntermediateFile, dataset, query_name,
            "-intermediate");
    // Config and Logger cannot collide on data key
    string_1d_t header;
    this->DefaultHeader(header);
    std::unordered_set<std::string> header_set(header.begin(), header.end());
    if (header.size() != header_set.size()) {
        PrintCTX("Config and Logger collide on data key, key list_size=");
        PrintLine(header.size() << " set_size=" << header_set.size());
        Print("current header list=");
        for (auto &item : header) {
            std::cout << item << std::endl;
        }
        SystemExit(-1);
    }
    // parameter check
    if (this->SaveIntermediateFile().size()) {
        if (this->SaveFile() == this->SaveIntermediateFile()) {
            PrintCTX("output file names " << this->SaveFile() << " and ");
            PrintLine(this->SaveIntermediateFile() << " cannot collide.");
            SystemExit(-1);
        }
    }
#ifdef LISTING
    if (this->SaveFile().empty()) {
        PrintCTX("LISTING requires [" << Config::KeySaveFile << "]");
        PrintLine(", set default value: save-file.txt");
        this->string_[Config::KeySaveFile] = "save-file.txt";
    }
#endif
    if (this->SaveIntermediateFile().size()) {
        /* write config information
         * https://stackoverflow.com/a/10151286
         * redirect std::cout to file and then restore
         *
         * save op_to_ph and abstract::Expression to file
         * then it map optim::Operand -> abstract::Operand -> sorttrie::Node
         */
        utility::MkFileDir(this->SaveIntermediateFile());
        std::ofstream out_file(this->SaveIntermediateFile(), std::ios::app);
        auto coutbuf = std::cout.rdbuf(out_file.rdbuf()); //save and redirect
        std::cout.rdbuf(coutbuf);   //reset to standard output again
    }
}

const std::string Config::KeyAlgorithm = "-algorithm";
const std::string Config::KeyAutomorphism = "-automorphism";
const std::string Config::KeyBinaryDirectory = "-binary-directory";
const std::string Config::KeyCompilerOutputMode = "-compiler-output-mode";
const std::string Config::KeyCostModel = "-cost-model";
const std::string Config::KeyDataFile = "-data-file";
const std::string Config::KeyDateTime = "-date-time";
const std::string Config::KeyEncodeVariable = "-encode-variable";
const std::string Config::KeyExecute = "-execute";
const std::string Config::KeyFunctionName = "-function-name";
const std::string Config::KeyGraphStorage = "-graph-storage";
const std::string Config::KeyIEPAlgorithm = "-iep-algorithm";
const std::string Config::KeyIEPCommonSet = "-iep-common-set";
const std::string Config::KeyIEPIntersectDP = "-iep-intersect-dp";
const std::string Config::KeyIEPIntersectSize = "-iep-intersect-size";
const std::string Config::KeyIEPSize = "-iep-size";
const std::string Config::KeyIndentSize = "-indent-size";
const std::string Config::KeyIsLabeled = "-is-labeled";
const std::string Config::KeyIsomorphism = "-isomorphism";
const std::string Config::KeyLabelFile = "-label-file";
const std::string Config::KeyOperandSize = "-operand-size";
const std::string Config::KeyOrderGenerator = "-order-generator";
const std::string Config::KeyOrderGeneratorAdd = "-order-generator-add";
const std::string Config::KeyPlan = "-plan";
const std::string Config::KeyPolynomial2006 = "-polynomial2006";
const std::string Config::KeyPolynomial2006DP = "-polynomial2006-dp";
const std::string Config::KeyQueryFile = "-query-file";
const std::string Config::KeyQueryName = "-query-name";
const std::string Config::KeyReadMinimalData = "-read-minimal-data";
const std::string Config::KeySampleCount = "-sample-count";
const std::string Config::KeySampleInducedSubgraph = "-sample-induced-subgraph";
const std::string Config::KeySampleRetryCount = "-sample-retry-count";
const std::string Config::KeySampleSubgraphSize = "-sample-subgraph-size";
const std::string Config::KeySaveFile = "-save-file";
const std::string Config::KeySaveIntermediateFile = "-save-intermediate-file";
const std::string Config::KeyShareSubquery = "-share-subquery";
const std::string Config::KeySymmetryBreaking = "-symmetry-breaking";
const std::string Config::KeyVersion = "Version";
const std::string Config::ValueAdhoc = "Adhoc";
const std::string Config::ValueAppend = "Append";
const std::string Config::ValueCSR0 = "CSR.0";
const std::string Config::ValueCSR1 = "CSR.1";
const std::string Config::ValueCleanAppend = "Clean";
const std::string Config::ValueCleanSort = "CleanSort";
const std::string Config::ValueCompile = "Compile";
const std::string Config::ValueDAG = "DAG";
const std::string Config::ValueDataQuery = "Data-Query";
const std::string Config::ValueDataQueryDateTime = "Data-Query-Date-Time";
const std::string Config::ValueDegreeLabel = "DegreeLabel";
const std::string Config::ValueEdgeInduce = "EdgeInduce";
const std::string Config::ValueGraphPi = "GraphPi";
const std::string Config::ValueHomomorphism = "Homomorphism";
const std::string Config::ValueHyperGeometry = "HyperGeometry";
const std::string Config::ValueNonAutomorphism = "NonAutomorphism";
const std::string Config::ValuePowerLaw = "PowerLaw";
const std::string Config::ValueRI = "RI";
const std::string Config::ValueRIDataGraph = "RIDataGraph";
const std::string Config::ValueRIImplement = "RIImplement";
const std::string Config::ValueSingleDirect = "SingleDirect";
const std::string Config::ValueSort = "Sort";
const std::string Config::ValueSortTrie = "SortTrie";
const std::string Config::ValueSymBreak2007 = "SymBreak2007";
const std::string Config::ValueSymBreakGraphPi = "SymBreakGraphPi";
const std::string Config::ValueTable = "Table";
const std::string Config::ValueTopDown = "TopDown";
const std::string Config::ValueTransitivity = "Transitivity";
const std::string Config::ValueTrie = "Trie";
const std::string Config::ValueVersion = "v0.3";
const std::string Config::ValueVersionDataQuery = "Version-Data-Query";
const std::string Config::ValueVersionDataQueryDateTime =
        "Version-Data-Query-Date-Time";
const std::string Config::ValueVertexInduce = "VertexInduce";
const std::string Config::ValueWCOJ = "WCOJ";

const std::string Config::FUNCTION_FILE = Config::ValueVersion
        + "-function.txt";
const std::string Config::LOG_FILE = Config::ValueVersion + "-log.csv";

} // namespace utility
