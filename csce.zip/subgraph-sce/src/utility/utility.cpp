/*
 * utility.cpp
 *
 *  Created on: Thursday 16:28 PM 2022-10-20
 *      Author: Hongtai Cao
 */

#include <cctype>

#include "include/utility/utility.hpp"

namespace utility {

uint64_t COUNTER_LOOP_0 = 0;
uint64_t COUNTER_LOOP_1 = 0;
uint64_t COUNTER_LOOP_2 = 0;
uint64_t COUNTER_LOOP_3 = 0;
uint64_t COUNTER_LOOP_4 = 0;
uint64_t COUNTER_LOOP_5 = 0;
uint64_t COUNTER_LOOP_6 = 0;
uint64_t COUNTER_LOOP_7 = 0;
uint64_t COUNTER_LOOP_8 = 0;
uint64_t COUNTER_LOOP_9 = 0;
uint64_t COUNTER_LOOP_10 = 0;
uint64_t COUNTER_LOOP_11 = 0;

std::string Join(const string_1d_t &str_1d, const std::string &sep) {
    std::string output;
    if (str_1d.size()) {
        output = str_1d[0];
        for (size_t ith = 1; ith < str_1d.size(); ith++) {
            output += (sep + str_1d[ith]);
        }
    }
    return output;
}

std::string KeepAlNum(const std::string &in_str, const char &replace) {
    // function name only allows alpha numerical characters
    std::string out_str;
    for (auto &ch : in_str) {
        if (std::isalnum(ch)) {
            out_str += ch;
        } else {
            // use _ for unsupported character
            out_str += replace;
        }
    }
    return out_str;
}

void MkRecursiveDir(const std::string &directory) {
    size_t found = 0;
    do {
        found = directory.find_first_of("/\\", found + 1);
        MkDir(directory.substr(0, found));
    } while (found < std::string::npos);
}

std::string Replace(const std::string &str, char a, char b) {
    std::string result;
    for (auto ch : str) {
        if (ch == a) {
            if (b != 0) {
                result += b;
            }
        } else {
            result += ch;
        }
    }
    return result;
}

string_1d_t Split(const std::string &in, const char sep) {
    size_t pos = 0;
    string_1d_t vec;
    for (size_t head = 0; head < in.size(); head++) {
        if (in[head] == sep) {
            if (head > pos) {
                vec.push_back(in.substr(pos, head - pos));
            }
            pos = head + 1;
        }
    }
    if (pos < in.size()) {
        vec.push_back(in.substr(pos));
    }
    return vec;
}

} // namespace utility
