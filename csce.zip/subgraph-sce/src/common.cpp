/*
 * common.cpp
 *
 *  Created on: 4:51 AM Friday Sep 15, 2023
 *      Author: hongt Hongtai Cao
 */

#include "include/common.hpp"

const eid_t DefaultLabel = 0;

/*
 * unconnected 0
 * bi-directed 1
 * in-coming 2
 * out-going 3
 */
const eid_t UnconnectedEdgeLabel = 0;
const eid_t BidirectedEdgeLabel = 1;
const eid_t IncomingEdgeLabel = 2;
const eid_t OutgoingEdgeLabel = 3;
