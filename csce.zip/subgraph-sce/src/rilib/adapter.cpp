/*
 * adapter.cpp
 *
 *  Created on: Wednesday, 18:54 PM Jul 5, 2023
 *      Author: Hongtai Cao
 */

#include <cstring>

#include "include/csr/codegen/query.hpp"
#include "include/rilib/adapter.hpp"

namespace rilib {

void BuildGraph(csr::codegen::Query &query, Graph &graph) {
    /* convert csr::codegen::Query graph to ri::Graph
     * modified from github.com/InfOmics/RI
     * file: include/c_textdb_driver.h
     * function: read_gfd
     */
    struct gr_neighs_t {
    public:
        int nid;
        gr_neighs_t *next;
    };
    int i, j;
    graph.nof_nodes = query.VertexCount();
    // node labels
    graph.nodes_attrs = (void**) malloc(graph.nof_nodes * sizeof(void*));
    for (i = 0; i < graph.nof_nodes; i++) {
        const char *label = query.Label(i).c_str();
        graph.nodes_attrs[i] = (char*) malloc(
                (strlen(label) + 1) * sizeof(char));
        strcpy((char*) graph.nodes_attrs[i], label);
    }
    //edges
    graph.out_adj_sizes = (int*) calloc(graph.nof_nodes, sizeof(int));
    graph.in_adj_sizes = (int*) calloc(graph.nof_nodes, sizeof(int));
    gr_neighs_t **ns_o = (gr_neighs_t**) malloc(
            graph.nof_nodes * sizeof(gr_neighs_t));
    for (i = 0; i < graph.nof_nodes; i++) {
        ns_o[i] = NULL;
    }
    for (auto &v_neighbor : query.vid_out_edge) {
        auto es = v_neighbor.first;
        for (auto et : v_neighbor.second) {
            graph.out_adj_sizes[es]++;
            graph.in_adj_sizes[et]++;
            if (ns_o[es] == NULL) {
                ns_o[es] = (gr_neighs_t*) malloc(sizeof(gr_neighs_t));
                ns_o[es]->nid = et;
                ns_o[es]->next = NULL;
            } else {
                gr_neighs_t *n = (gr_neighs_t*) malloc(sizeof(gr_neighs_t));
                n->nid = et;
                n->next = (struct gr_neighs_t*) ns_o[es];
                ns_o[es] = n;
            }
        }
    }
    // adjacency list
    graph.out_adj_list = (int**) malloc(graph.nof_nodes * sizeof(int*));
    graph.in_adj_list = (int**) malloc(graph.nof_nodes * sizeof(int*));
    graph.out_adj_attrs = (void***) malloc(graph.nof_nodes * sizeof(void**));
    int *ink = (int*) calloc(graph.nof_nodes, sizeof(int));
    for (i = 0; i < graph.nof_nodes; i++) {
        graph.in_adj_list[i] = (int*) calloc(graph.in_adj_sizes[i],
                sizeof(int));
    }
    for (i = 0; i < graph.nof_nodes; i++) {
        // reading degree and successors of vertex i
        graph.out_adj_list[i] = (int*) calloc(graph.out_adj_sizes[i],
                sizeof(int));
        graph.out_adj_attrs[i] = (void**) malloc(
                graph.out_adj_sizes[i] * sizeof(void*));

        gr_neighs_t *n = ns_o[i];
        for (j = 0; j < graph.out_adj_sizes[i]; j++) {
            graph.out_adj_list[i][j] = n->nid;
            graph.out_adj_attrs[i][j] = NULL;

            graph.in_adj_list[n->nid][ink[n->nid]] = i;
            ink[n->nid]++;

            n = n->next;
        }
    }
//  graph.sort_edges();
    free(ink);
    for (int i = 0; i < graph.nof_nodes; i++) {
        if (ns_o[i] != NULL) {
            gr_neighs_t *p = NULL;
            gr_neighs_t *n = ns_o[i];
            for (j = 0; j < graph.out_adj_sizes[i]; j++) {
                free(p);
                p = n;
                n = n->next;
            }
            free(p);
        }
    }
    free(ns_o);
}

void MatchVertex(csr::codegen::Query &query, string_1d_t &match_vertex) {
    // Query vertices to match in sequence
    Graph ri_graph;
    BuildGraph(query, ri_graph);
    // ri matching machine heuristic: most constraint vertex first
    MaMaConstrFirst matchmachine(ri_graph);
    matchmachine.build(ri_graph);
    for (int i = 0; i < matchmachine.nof_sn; i++) {
        match_vertex.push_back(
                std::to_string(matchmachine.map_state_to_node[i]));
    }
}

} // namespace rilib
