/*
 * main.cpp
 *
 * perform subgraph matching
 *
 *  Created on: 1:39 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/csr/dynamic/execute.hpp"
#include "include/csr/graph.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace csr {

void main(utility::Config &config, utility::Logger &logger) {
    BuildGraphBinary(config);
    const utility::timepoint_t &start = utility::GetTimepoint();
    Graph graph(config);
    logger.DurationReadBinaryGraph = utility::GetDuration(start);
    PrintLCTX("DurationReadBinaryGraph(s)=" << logger.DurationReadBinaryGraph);
    // graph.WriteEdgelistText(config.LabelFile(), "data.csr.txt");
    dynamic::ExecuteDynamic(config, graph, logger);
}

} // namespace csr

int main(int argc, char *argv[]) {
    utility::Config config = utility::Config(argc, argv);
    utility::Logger logger;
    if (config.GraphStorageCSR()) {
        csr::main(config, logger);
    } else {
        PrintLCTX("unknown GraphStorage [" << config.GraphStorage() << "]");
        SystemExit(-1);
    }
    config.SaveToFile(logger);
    PrintLCTX("stop command line at " << utility::GetCurrentTime());
    return 0;
}
