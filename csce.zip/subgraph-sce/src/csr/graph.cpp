/*
 * graph.cpp
 *
 * handle labeled graph and symmetry breaking
 *
 *  Created on: 18:53 PM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <fstream>
#include <unordered_set>
#include <vector>

#include "include/common.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/query.hpp"
#include "include/edgelist/graph.hpp"
#include "include/utility/config.hpp"
#include "include/utility/graph.hpp"
#include "include/utility/utility.hpp"

namespace csr {

// local function
namespace v0 {

inline void ReadCSRData(std::ifstream &in, rid_t *&row_index, vid_t row_size,
        cid_t *&column_index, eid_t column_size) {
    row_index = new rid_t[row_size];
    column_index = new cid_t[column_size];
    in.read(reinterpret_cast<char *>(row_index), sizeof(rid_t) * row_size);
    in.read(reinterpret_cast<char *>(column_index),
            sizeof(cid_t) * column_size);
}

inline void ReadCSRSize(std::ifstream &in, vid_t &row_size,
        eid_t& column_size) {
    in.read(reinterpret_cast<char *>(&row_size), sizeof(vid_t));
    in.read(reinterpret_cast<char *>(&column_size), sizeof(eid_t));
}

void ReadCluster(std::ifstream &in, csize_t label_size, vid_t *row_size,
        rid_t **row_index, cid_t **column_index, csize_t *qlabel_1d,
        const csize_t qlabel_size) {
    // qlabel_1d should be sorted in ascending order
    eid_t column_size = 0;
    if (qlabel_size) {
        // read query related data, based on query label id (ilabel)
        csize_t j = 0;
        for (csize_t label_id = 0; label_id < label_size; label_id++) {
            ReadCSRSize(in, row_size[label_id], column_size);
            while ((j < qlabel_size) and (qlabel_1d[j] < label_id)) {
                j++;
            }
            if ((j < qlabel_size) and (qlabel_1d[j] == label_id)) {
                /* does not finish reading query related data
                 * query has this label id. read it
                 */
                ReadCSRData(in, row_index[label_id], row_size[label_id],
                        column_index[label_id], column_size);
            } else {
                /* finish reading query related data
                 * or
                 * current label does not appear in query. skip reading
                 *
                 * need to move cursor correctly
                 */
                in.seekg(
                        sizeof(rid_t) * row_size[label_id]
                                + sizeof(cid_t) * column_size,
                        std::ios_base::cur);
                // dummy data for delete
                row_size[label_id] = 0;
                row_index[label_id] = nullptr;
                column_index[label_id] = nullptr;
            }
        }
    } else {
        // read the entire graphs for all labels
        for (csize_t label_id = 0; label_id < label_size; label_id++) {
            ReadCSRSize(in, row_size[label_id], column_size);
            ReadCSRData(in, row_index[label_id], row_size[label_id],
                    column_index[label_id], column_size);
        }
    }
}

void WriteBinary(utility::Config &config) {
    /* binary data format
     * vertex_size
     * max_degree
     * label_size
     * row index size [0]
     * column index size
     * row index data [0]
     * column index data [0]
     * row index size [1]
     * column index size
     * row index data [1]
     * column index data [1]
     * ...
     * row index size [label size - 1]
     * column index size
     * row index data [label size - 1]
     * column index data [label size - 1]
     *
     * row size is the length of row_index for a specific label
     * use row_size per vertex label can save memory a bit
     * use (vertex_count + 1) can avoid range check
     */
    edge_map_1d_t edge_map_1d;
    std::ofstream out = utility::graph::OutBinary(config.BinaryGraph());
    vid_t cluster_count = 0;
    const vid_t vertex_count = utility::graph::PrepareBinary(config, out,
            edge_map_1d, cluster_count);
    /* row size is the length of row_index for a specific label
     * use row_size per vertex label can save memory a bit
     * use (vertex_count + 1) can avoid range check
     */
    vid_t r_size = vertex_count + 1;
    rid_t *row_index = new rid_t[r_size];
    cid_t *column_index = nullptr;
    for (size_t i = 0; i < cluster_count; i++) {
        auto &e_map = edge_map_1d[i];
        // collect the number of edges
        eid_t c_size = 0;
        for (auto it = e_map.begin(); it != e_map.end(); it++) {
            c_size += it->second.size();
        }
        delete[] column_index;
        column_index = new cid_t[c_size];
        // collect neighbor for each vertex
        c_size = 0;
        vid_t v = 0;
        for (; v < vertex_count; v++) {
            row_index[v] = c_size;
            if (e_map.count(v)) {
                std::vector<vid_t> n_1d(e_map[v].begin(), e_map[v].end());
                std::sort(n_1d.begin(), n_1d.end());
                for (auto neighbor : n_1d) {
                    column_index[c_size] = neighbor;
                    c_size++;
                }
            }
        }
        row_index[v] = c_size;
        // binary data format
        out.write(reinterpret_cast<char *>(&r_size), sizeof(vid_t));
        out.write(reinterpret_cast<char *>(&c_size), sizeof(eid_t));
        out.write(reinterpret_cast<char *>(row_index),
                sizeof(rid_t) * (r_size));
        out.write(reinterpret_cast<char *>(column_index),
                sizeof(cid_t) * (c_size));
    }
    delete[] row_index;
    delete[] column_index;
    out.close();
}

} // namespace v0

namespace v1 {

inline void ReadCSRColumn(std::ifstream &in, cid_t *&col_index,
        const eid_t col_size) {
    col_index = new cid_t[col_size];
    in.read(reinterpret_cast<char *>(col_index), sizeof(cid_t) * col_size);
}

void ReadCSRRow(std::ifstream &in, rid_t *&row_index, const vid_t r_size,
        const vid_t offset_count) {
    rid_t *data = new rid_t[offset_count];
    in.read(reinterpret_cast<char *>(data), sizeof(rid_t) * offset_count);
    // convert data into row_index
    row_index = new rid_t[r_size];
    rid_t counter = 0;
    for (size_t ith = 0; ith < offset_count; ith += 2) {
        rid_t index = data[ith];
        rid_t duplicate = data[ith + 1];
        for (size_t jth = 0; jth < duplicate; jth++) {
            row_index[counter++] = index;
        }
    }
    delete[] data;
}

inline void ReadCSRSize(std::ifstream &in, vid_t &row_size,
        eid_t& column_size) {
    in.read(reinterpret_cast<char *>(&row_size), sizeof(vid_t));
    in.read(reinterpret_cast<char *>(&column_size), sizeof(eid_t));
}

void ReadCluster(std::ifstream &in, const vid_t vertex_count,
        csize_t cluster_count, vid_t *row_size, rid_t **row_index,
        cid_t **column_index, csize_t *qcluster_1d,
        const csize_t qcluster_size) {
    // qcluster_1d should be sorted in ascending order
    vid_t offset_count = 0;
    eid_t column_size = 0;
    // because of this line, there is no need to revise row_size array
    const vid_t r_size = vertex_count + 1;
    if (qcluster_size) {
        // read query related data, based on query cluster id (cid)
        csize_t j = 0;
        for (csize_t cid = 0; cid < cluster_count; cid++) {
            ReadCSRSize(in, offset_count, column_size);
            while ((j < qcluster_size) and (qcluster_1d[j] < cid)) {
                j++;
            }
            if ((j < qcluster_size) and (qcluster_1d[j] == cid)) {
                /* does not finish reading query related data
                 * query has this label id. read it
                 */
                ReadCSRRow(in, row_index[cid], r_size, offset_count);
                ReadCSRColumn(in, column_index[cid], column_size);
                row_size[cid] = vertex_count;
            } else {
                /* finish reading query related data
                 * or
                 * current label does not appear in query. skip reading
                 *
                 * need to move cursor correctly
                 */
                in.seekg(
                        sizeof(rid_t) * offset_count
                                + sizeof(cid_t) * column_size,
                        std::ios_base::cur);
                // dummy data for delete
                row_size[cid] = 0;
                row_index[cid] = nullptr;
                column_index[cid] = nullptr;
            }
        }
    } else {
        // read the entire graphs for all labels
        for (csize_t cid = 0; cid < cluster_count; cid++) {
            ReadCSRSize(in, offset_count, column_size);
            ReadCSRRow(in, row_index[cid], r_size, offset_count);
            ReadCSRColumn(in, column_index[cid], column_size);
            row_size[cid] = vertex_count;
        }
    }
}

void WriteBinary(utility::Config &config) {
    /* v0 has a limitation of low space efficiency
     * row_index is stored for each cluster
     * if there are many clusters, then too many copies of row_index
     * if many vertices do not have neighbors,
     * then row_index contains many duplicate offset to show 0 neighbors
     * this is be improved by store offset and offset duplicate count
     * which essentially changes the row_index size
     */
    edge_map_1d_t edge_map_1d;
    std::ofstream out = utility::graph::OutBinary(config.BinaryGraph());
    vid_t cluster_count = 0;
    const vid_t vertex_count = utility::graph::PrepareBinary(config, out,
            edge_map_1d, cluster_count);
    // worst case length. every vertex has neighbors, offset + duplicate
    rid_t *row_index = new rid_t[(vertex_count + 1) * 2];
    cid_t *column_index = nullptr;
    for (size_t i = 0; i < cluster_count; i++) {
        auto &e_map = edge_map_1d[i];
        // collect the number of edges
        eid_t c_size = 0;
        for (auto it = e_map.begin(); it != e_map.end(); it++) {
            c_size += it->second.size();
        }
        delete[] column_index;
        column_index = new cid_t[c_size];
        // collect neighbor for each vertex
        vid_t r_size = 1;
        vid_t duplicate = 1;
        row_index[0] = 0;
        c_size = 0;
        for (vid_t v = 0; v < vertex_count; v++) {
            if (e_map.count(v)) {
                std::vector<vid_t> n_1d(e_map[v].begin(), e_map[v].end());
                std::sort(n_1d.begin(), n_1d.end());
                for (auto neighbor : n_1d) {
                    column_index[c_size] = neighbor;
                    c_size++;
                }
                // duplicate of the previous offset
                row_index[r_size++] = duplicate;
                // end offset of the current, the number of edges
                row_index[r_size++] = c_size;
                duplicate = 1;
            } else {
                duplicate++;
            }
        }
        row_index[r_size++] = duplicate;    // end row_index with duplicate
        // binary data format
        out.write(reinterpret_cast<char *>(&r_size), sizeof(vid_t));
        out.write(reinterpret_cast<char *>(&c_size), sizeof(eid_t));
        out.write(reinterpret_cast<char *>(row_index),
                sizeof(rid_t) * (r_size));
        out.write(reinterpret_cast<char *>(column_index),
                sizeof(cid_t) * (c_size));
    }
    delete[] row_index;
    delete[] column_index;
    out.close();
}

} // namespace v1

// public function
void BuildGraphBinary(utility::Config &config) {
    std::string bin_file = config.BinaryGraph();
    if (utility::graph::HasBinary(bin_file, config.LabelFile())) {
        return;
    }
    PrintLCTX("create files for a binary CSR graph at:");
    PrintLCTX(bin_file);
    PrintLCTX(config.LabelFile());
    /* convert a graph in text (graph_file) to a binary dataset
     * create data_file and label_file if any is missing
     * create CSR for each cluster id, 0 <= cluster id < cluster_count
     */
    if (config.GraphStorageCSR1()) {
        v1::WriteBinary(config);
    } else if (config.GraphStorageCSR0()) {
        v0::WriteBinary(config);
    } else {
        PrintLCTX("csr unknown storage [" << config.GraphStorage() << "]");
        SystemExit(-1);
    }
}

// public method
void Graph::WriteEdgelistText(const std::string &label_file,
        const std::string &out_file) const {
    // used for test purpose
    // map edge string to cluster index
    string_index_t edge_to_clusterindex;
    for (csize_t idx = 0; idx < this->cluster_size_; idx++) {
        auto row = this->row_index_[idx];
        auto column = this->column_index_[idx];
        for (vid_t src = 0; src < this->row_size_[idx]; src++) {
            for (eid_t e_id = row[src]; e_id < row[src + 1]; e_id++) {
                edge_to_clusterindex[ToString2(src, column[e_id])] = idx;
            }
        }
    }
    // finally write
    edgelist::WriteGraphText(edge_to_clusterindex, label_file, out_file);
}

Graph::Graph(utility::Config &config)
        : optim::Graph(config.BinaryGraph(), config.LabelFile()) {
    // continue to read storage specific binary data
    this->row_size_ = new vid_t[this->cluster_size_];
    this->row_index_ = new rid_t*[this->cluster_size_];
    this->column_index_ = new cid_t*[this->cluster_size_];
    csize_t *qlabel_1d = nullptr;
    csize_t qlabel_size = 0;
    if (config.ReadMinimalData()) {
        // need to read the query graph
        Query query(config.QueryFile(), config.LabelFile(), config.IsLabeled());
        this->query_size_ = query.VertexCount();
        std::unordered_set<csize_t> index_set;
        if (config.IsomorphismVertexInduce()) {
            // read label index for all vertex pairs due to negation
            for (size_t va = 0; va < this->query_size_; va++) {
                for (size_t vb = 0; vb < this->query_size_; vb++) {
                    if (va != vb) {
                        const auto &index_1d = query.AllClusterIndex(va, vb);
                        index_set.insert(index_1d.begin(), index_1d.end());
                    }
                }
            }
        } else {
            // read label index for edges only
            for (const auto &pair : query.out_edge) {
                for (auto vb : pair.second) {
                    index_set.insert(query.Index(pair.first, vb));
                    // required for directed graphs
                    index_set.insert(query.Index(vb, pair.first));
                }
            }
        }
        qlabel_1d = new csize_t[index_set.size()];
        for (auto index : index_set) {
            qlabel_1d[qlabel_size] = index;
            qlabel_size++;
        }
        std::sort(qlabel_1d, qlabel_1d + qlabel_size);
    } else {
        this->query_size_  = 0;
    }
    if (config.GraphStorageCSR1()) {
        v1::ReadCluster(this->in_, this->vertex_size_, this->cluster_size_,
                this->row_size_, this->row_index_, this->column_index_,
                qlabel_1d, qlabel_size);
        // row_size[row_id] is (1 + the size of row_index[row_id])
    } else if (config.GraphStorageCSR0()) {
        v0::ReadCluster(this->in_, this->cluster_size_, this->row_size_,
                this->row_index_, this->column_index_, qlabel_1d, qlabel_size);
        /* row_size[row_id] is the size of row_index[row_id]
         * however, when scanning row_index[row_id]
         * it should stop at row_size[row_id] - 1
         */
        for (csize_t cid = 0; cid < this->cluster_size_; cid++) {
            if (this->row_size_[cid] > 0) {
                this->row_size_[cid]--;
            }
        }
    } else {
        PrintLCTX("csr unknown storage [" << config.GraphStorage() << "]");
        SystemExit(-1);
    }
    delete qlabel_1d;
    this->in_.close();
}

Graph::~Graph() {
    // delete data graph
    if (this->cluster_size_ == 0) {
        // if nothing allocated
        return;
    }
    this->cluster_size_--;
    while (this->cluster_size_ > 0) {
        // index_size_ is unsigned, has to use 0 to end the loop
        delete[] this->row_index_[this->cluster_size_];
        delete[] this->column_index_[this->cluster_size_];
        this->cluster_size_--;
    }
    // delete the last item
    delete[] this->row_index_[0];
    delete[] this->column_index_[0];
    // delete the array of pointers
    delete[] this->row_size_;
    delete[] this->row_index_;
    delete[] this->column_index_;
}

} // namespace graph
