/*
 * out.cpp
 *
 *  Created on: 13:35 PM Thursday 2023-6-22
 *      Author: Hongtai Cao
 */

#include "include/common.hpp"
#include "include/csr/codegen/out.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/neighborset.hpp"
#include "include/csr/vertexset.hpp"

namespace csr {

namespace compile {

namespace codegen {

// begin auto-generation

// begin initialize e_map
expression_map_t InitializeExpressionMap() {
    expression_map_t e_map;
// end auto-generation
    return e_map;
}

} // namespace codegen

} // namespace compile

} // namespace csr
