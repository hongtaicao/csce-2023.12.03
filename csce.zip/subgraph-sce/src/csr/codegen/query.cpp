/*
 * query.cpp
 *
 *  Created on: 9:35 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include "include/csr/codegen/query.hpp"
#include "include/edgelist/graph.hpp"
#include "include/edgelist/label.hpp"

namespace csr {

namespace codegen {

// local function
inline std::string VidToStr(vid_t vertex) {
    return std::to_string(vertex);
}

// public method
codegen::Query::Query(const std::string &query_file,
        const std::string &label_file, bool is_labeled) {
    edgelist::edge_to_array4_t label_map;
    edgelist::ReadGraphText(is_labeled, query_file, this->vid_out_edge,
            label_map);
    string_index_t labelstr_index;
    edgelist::ReadLabelFileText(label_file, labelstr_index);
    this->index_count_ = labelstr_index.size();
    /* build max_vertex and this->vertex_set_
     * validate query vertex integer range
     */
    vid_t max_vertex = edgelist::MaxVertex(this->vid_out_edge);
    edgelist::GetVertexSet(this->vid_out_edge, this->vertex_set_);
    if ((max_vertex + 1) != this->vertex_set_.size()) {
        /* this->vertex_to_label_ is an array
         * it requires query vertices to be consecutive integers
         */
        PrintCTX("error: query vertices are not consecutive integers");
        PrintLine(" starting from 0");
        PrintLine("query file=" << query_file);
        SystemExit(-1);
    }
    // build this->edge_to_cindex_
    edgelist::GetEdgeToIndex(this->vid_out_edge, label_map, labelstr_index,
            VidToStr, this->edge_to_cindex_);
    // build this->vertex_to_label_
    edgelist::GetVertexLabel(this->vid_out_edge, label_map, this->VertexCount(),
            this->int_vertex_to_label_);
    // build this->vplabel_to_edgeindex_
    edgelist::GetVertexPairLabel(this->int_vertex_to_label_,
            this->vplabel_to_edgeindex_);
    edgelist::GetVertexPairToIndex(labelstr_index, VidToStr,
            this->vplabel_to_edgeindex_);
    // build this->string_vertex_to_label_
    for (size_t v = 0; v < this->int_vertex_to_label_.size(); v++) {
        this->string_vertex_to_label_[std::to_string(v)] =
                this->int_vertex_to_label_[v];
    }
    // build this->string_out_edge_ and this->string_in_edge_
    this->string_out_edge_.reserve(this->vid_out_edge.size());
    for (auto &v_neighbor : this->vid_out_edge) {
        auto va = std::to_string(v_neighbor.first);
        auto &neighbor_set = this->string_out_edge_[va];
        for (auto neighbor : v_neighbor.second) {
            auto vb = std::to_string(neighbor);
            neighbor_set.insert(vb);
            this->string_in_edge_[vb].insert(va);
        }
    }
}

size_t codegen::Query::Degree(const std::string &vertex) {
    /* this is not simply adding InDegree and OutDegree
     * because undirected neighbors are both in-neighbors and out-neighbor
     */
    vid_t degree = 0;
    vid_t va = std::stoi(vertex);
    for (auto vb : this->vertex_set_) {
        if (this->HasEdge(va, vb) or this->HasEdge(vb, va)) {
            degree++;
        }
    }
    return degree;
}

bool codegen::Query::IsVertexSet(const string_set_t &vertex_set) {
    if (vertex_set.size() != this->vertex_set_.size()) {
        return false;
    }
    for (const auto &item : vertex_set) {
        vid_t vertex = std::stoi(item);
        if (not this->vertex_set_.count(vertex)) {
            return false;
        }
    }
    return true;
}

} // namespace codegen

} // namespace csr
