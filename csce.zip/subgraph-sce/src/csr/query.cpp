/*
 * query.cpp
 *
 * csr::codegen::Query is string based
 * this is integer based
 *
 *  Created on: 16:56 PM Saturday Sep 2, 2023
 *      Author: hongt Hongtai Cao
 */

#include "include/csr/query.hpp"
#include "include/edgelist/graph.hpp"
#include "include/edgelist/label.hpp"

namespace csr {

// local function
inline vid_t VidToVid(vid_t vertex) {
    return vertex;
}

// public method
Query::Query(const std::string &query_file, const std::string &label_file,
        bool is_labeled) {
    edgelist::edge_to_array4_t label_map;
    edgelist::ReadGraphText(is_labeled, query_file, this->out_edge, label_map);
    string_index_t clusterkey_index;
    edgelist::ReadLabelFileText(label_file, clusterkey_index);
    /* build max_vertex and vset
     * validate query vertex integer range
     */
    vid_t max_vertex = edgelist::MaxVertex(this->out_edge);
    vid_set_t vset;
    edgelist::GetVertexSet(this->out_edge, vset);
    if ((not vset.empty()) and (max_vertex + 1 != vset.size())) {
        PrintCTX("Query vertex should be consecutive integers from 0.");
        Print(" vertex count=" << vset.size() << " max vertex=" << max_vertex);
        PrintLine("");
        SystemExit(-1);
    }
    // build this->edge_to_cindex_
    edgelist::GetEdgeToIndex(this->out_edge, label_map, clusterkey_index,
            VidToVid, this->edge_to_cindex_);
    // build vertex_to_label
    edgelist::GetVertexLabel(this->out_edge, label_map, vset.size(),
            this->vertex_to_label_);
    // build this->vplabel_to_edgeindex_
    edgelist::GetVertexPairLabel(this->vertex_to_label_,
            this->vplabel_to_cindex_);
    edgelist::GetVertexPairToIndex(clusterkey_index, VidToVid,
            this->vplabel_to_cindex_);
}

} // namespace csr
