/*
 * vertexset.cpp
 *
 *  Created on: 18:53 PM Monday 2023-4-17
 *      Author: Hongtai Cao
 */

#include "include/csr/vertexset.hpp"

namespace csr {

/* Initialization
 * "Undefined reference" to declared C++ static member variable
 * https://stackoverflow.com/a/35566023
 * need to be initialized in one source file
 *
 * error: definition of 'csr::VertexSet::MAX_SIZE' is not in namespace
 * enclosing 'csr::VertexSet'
 */
vid_t VertexSet::MAX_SIZE = 1;

void VertexSet::QuickSort(vid_t head, vid_t tail) {
    if (tail - head > 1) {
        size_t pivot = this->QuickSortPartition(head, tail);
        this->QuickSort(head, pivot);
        this->QuickSort(pivot + 1, tail);
    }
}

vid_t VertexSet::QuickSortPartition(vid_t head, vid_t tail) {
    vid_t value = this->data[tail - 1], smaller = head;
    // smaller points to an empty slot
    for (; head < tail; head++) {
        vid_t temp = this->data[head];
        if (temp <= value) {
            this->data[head] = this->data[smaller];
            this->data[smaller] = temp;
            smaller++;
        }
    }
    return smaller - 1;
}

} // namespace csr
