/*
 * optimizer.cpp
 *
 *  Created on: Wednesday 14:25 PM Jul 5, 2023
 *      Author: Hongtai Cao
 */

#include <string>

#include "include/csr/codegen/query.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/optimizer.hpp"
#include "include/optim/ordergenerator/dag.hpp"
#include "include/optim/ordergenerator/ri.hpp"
#include "include/optim/query.hpp"
#include "include/rilib/adapter.hpp"
#include "include/utility/config.hpp"

namespace csr {

typedef optim::ordergenerator::DAG DAG;
typedef optim::ordergenerator::RI RI;

// public function
void BuildMatchVertex(Config &config, Graph &graph, codegen::Query &query,
        string_1d_t &match_vertex) {
    // Query vertices to match in sequence
    match_vertex.reserve(query.VertexCount());
    const std::string &plan = config.Plan();
    if (plan.empty()) {
        if (config.OrderGeneratorRIImplement()
                or config.OrderGeneratorRIDataGraph()) {
            auto *optim_query = optim::ReadQuery(config);
            RI ri(config, graph, *optim_query);
            if (config.OrderGeneratorAddDAG()) {
                DAG dag(config, graph, *optim_query, ri.permutation);
                for (auto vertex : dag.permutation) {
                    match_vertex.push_back(std::to_string(vertex));
                }
            } else {
                for (auto vertex : ri.permutation) {
                    match_vertex.push_back(std::to_string(vertex));
                }
            }
            delete optim_query;
        } else if (config.OrderGeneratorRI()) {
            // the original RI implementation
            rilib::MatchVertex(query, match_vertex);
        } else {
            PrintLCTX("No OrderGenerator Algorithm is given.");
            SystemExit(-1);
        }
        return;
    }
    // a plan is given, parse into vertex sequence
    size_t head = 0;
    for (size_t ith = 0; ith < plan.size(); ith++) {
        const auto &ch = plan[ith];
        if ((ch < '0') or (ch > '9')) {
            if (head < ith) {
                match_vertex.push_back(plan.substr(head, ith - head));
            }
            head = ith + 1;
        }
    }
    if (head < plan.size()) {
        match_vertex.push_back(plan.substr(head));
    }
    string_set_t vertex_set(match_vertex.begin(), match_vertex.end());
    if (vertex_set.size() < match_vertex.size()) {
        PrintLCTX("find duplicate vertex. invalid plan error.");
        SystemExit(-1);
    }
    if (not query.IsVertexSet(vertex_set)) {
        PrintLCTX("plan and query vertex set mismatch. invalid plan error.");
        SystemExit(-1);
    }
}

} // namespace csr
