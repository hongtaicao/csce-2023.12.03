/*
 * base.cpp
 *
 *  Created on: Sep 25, 2023
 *      Author: hongt
 */

#include "include/csr/dynamic/base.hpp"
#include "include/csr/neighborset.hpp"

namespace csr {

namespace dynamic {

#if !defined(COUNTING) and defined(LISTING)
void OutputResult(const vid_1d_t &result) {
    OUTPUT << result[0];
    for (size_t ith = 1; ith < result.size(); ith++) {
        OUTPUT << " " << result[ith];
    }
    OUTPUT << std::endl;
}
#endif

void Base::Match() {
    /* warning: pure virtual ‘virtual void InitializeCandidateSet()’
     * called from constructor
     *
     * https://stackoverflow.com/a/14831145/11193802
     *
     * call a pure virtual method in base class constructor is bad
     * the method is resolved to the base class one (pure virtual)
     * and therefore is undefined
     */
    if (this->match_vertex_.size() < 2) {
        // does not match vertices
        return;
    }
    this->InitializeCandidateSet();
    this->result_.resize(this->match_vertex_.size());
    // solve match_vertex_[0]
    for (vid_t v = 0; v < this->graph_.VertexSize(); v++) {
        this->result_[0] = v;
        if (this->UpdateNSet(0)) {
            continue;
        }
        // no need to update VSet
        // solve match_vertex_[1]
        NeighborSet &nset = this->NSet(0, 1);
        for (vid_t index = 0; index < nset.size; index++) {
            this->result_[1] = nset.Vertex(index);
            if (this->UpdateNSet(1) or this->UpdateVSet(1)) {
                continue;
            }
            this->Match(2);
        }
    }
}

void Base::Match(const size_t ith) {
    if (ith == this->match_vertex_.size()) {
        // find a complete result
        OutputResult(this->result_);
        return;
    }
    VertexSet &vset = this->VSet(ith - 1, ith);
    for (size_t index = 0; index < vset.size; index++) {
        this->result_[ith] = vset.Vertex(index);
        if (this->UpdateNSet(ith) or this->UpdateVSet(ith)) {
            continue;
        }
        this->Match(ith + 1);
    }
}

bool Base::UpdateNSet(const size_t pi) {
    /* update NeighborSet that can be computed from
     * Graph vertex that matched Query match_vertex_[index]
     * such NeighborSet match Query match_vertex_[kth], kth > index
     * index is pi
     *
     * find NeighborSet to build candidates for query vertices
     * below dynamic execute does not find the equivalence
     * but computes it directly
     */
    const vid_t vertex = this->result_[pi];
    for (size_t ci = pi + 1; ci < this->match_vertex_.size(); ci++) {
        if (this->IsConnected(pi, ci)) {
            this->NSet(pi, ci) = this->IndexNeighborSet(pi, ci, vertex);
            /* (pi, ci) are connected and therefore
             * ci candidate must be from this->NSet(pi, ci)
             * can EarlyTerminateSize0
             */
            DebugPrint(pi, ci, this->NSet(pi, ci));
            EarlyTerminateSize0(this->NSet(pi, ci));
        } else {
            // initialize all NeighborSet for unconnected edges (negation)
            this->UpdateNSet(pi, ci);
        }
    }
    return false;
}

} // namespace dynamic

} // namespace csr
