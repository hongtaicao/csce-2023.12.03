/*
 * execute.cpp
 *
 *  Created on: 22:51 PM Wednesday Aug 30, 2023
 *      Author: hongt Hongtai Cao
 */

#include <string>           // std::stoull

#include "include/csr/codegen/query.hpp"
#include "include/csr/dynamic/edgeinduce.hpp"
#include "include/csr/dynamic/execute.hpp"
#include "include/csr/dynamic/homomorphism.hpp"
#include "include/csr/dynamic/vertexinduce.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/optimizer.hpp"
#include "include/csr/query.hpp"
#include "include/csr/utility.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace csr {

namespace dynamic {

bool ExecuteDynamic(Config &config, Graph &graph, Logger &logger) {
    csr::codegen::Query query(config.QueryFile(), config.LabelFile(),
            config.IsLabeled());
    const utility::timepoint_t &start = utility::GetTimepoint();
    string_1d_t match_vertex;
    BuildMatchVertex(config, graph, query, match_vertex);
    logger.DurationBuildOne = utility::GetDuration(start);
    logger.MatchVertex = utility::Join(match_vertex, " ");
    vid_1d_t match_sequence;
    match_sequence.reserve(match_vertex.size());
    for (const auto &vertex : match_vertex) {
        match_sequence.push_back(std::stoull(vertex, nullptr));
    }
    // max possible candidate VertexSet size
    vid_t max_size = graph.MaxDegree();
    if (query.VertexCount() > max_size) {
        max_size = query.VertexCount();
    }
    if (Before(config, max_size)) {
        const utility::timepoint_t &start = utility::GetTimepoint();
        csr::Query csr_query(config.QueryFile(), config.LabelFile(),
                config.IsLabeled());
        if (config.IsomorphismEdgeInduce()) {
            // EdgeInduce(graph, csr_query, match_sequence);
            EdgeInduce(graph, csr_query, match_sequence);
        } else if (config.IsomorphismHomomorphism()) {
            // Homomorphism(graph, csr_query, match_sequence);
            Homomorphism(graph, csr_query, match_sequence);
        } else if (config.IsomorphismVertexInduce()) {
            VertexInduce(graph, csr_query, match_sequence);
        } else {
            PrintLCTX("Unknown subgraph isomorphism. skip.");
            return false;
        }
        logger.DurationExecutionDynamic = utility::GetDuration(start);
        logger.MatchCount = After(config);
        PrintCTX("DurationExecution(s)=");
        Print(logger.DurationExecutionDynamic << " MatchCount=");
        PrintLine(logger.MatchCount);
        utility::PrintLoopCounter(true);
        return true;
    }
    return false;
}

} // namespace dynamic

} // namespace csr
