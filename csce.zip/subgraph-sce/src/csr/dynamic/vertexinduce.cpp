/*
 * vertexinduce.cpp
 *
 *  Created on: 3:30 AM Monday Sep 25, 2023
 *      Author: hongt Hongtai Cao
 */

#include "include/csr/dynamic/vertexinduce.hpp"

namespace csr {

namespace dynamic {

void VertexInduce::InitializeCandidateSet() {
    const size_t n = this->match_vertex_.size();
    if (n > 2) {
        this->nset_2d_.resize((n - 1) * n / 2);
        this->vset_1d_.resize((n - 2) * (n - 1) / 2);
    } else if (n == 2) {
        this->nset_2d_.resize(1);
    }
    for (size_t pi = 0; pi < this->match_vertex_.size() - 1; pi++) {
        for (size_t ci = pi + 1; ci < this->match_vertex_.size(); ci++) {
            if (this->IsConnected(pi, ci)) {
                // add 1 NeighborSet
                this->NSet1d(pi, ci).emplace_back(nullptr, 0);
            } else {
                // add NeighborSet for all ClusterIndex
                const size_t max_size = this->AllClusterIndex(pi, ci).size();
                if (max_size) {
                    auto &nset_1d = this->NSet1d(pi, ci);
                    nset_1d.reserve(max_size);
                    for (size_t ith = 0; ith < max_size; ith++) {
                        nset_1d.emplace_back(nullptr, 0);
                    }
                }
            }
        }
    }
}

void VertexInduce::UpdateNSet(const size_t pi, const size_t ci) {
    // initialize all NeighborSet for unconnected edges (negation)
    const auto vertex = this->result_[pi];
    auto label_1d = this->AllClusterIndex(pi, ci);
    auto &nset_1d = this->NSet1d(pi, ci);
    for (size_t ith = 0; ith < label_1d.size(); ith++) {
        nset_1d[ith] = this->IndexNeighborSet(label_1d[ith], vertex);
        /* this is unconnected edges
         * NeighborSet contains candidates that should be removed
         * therefore NeighborSet can be empty
         * cannot EarlyTerminateSize0
         */
        DebugPrint(pi, ci, nset_1d[ith]);
    }
}

bool VertexInduce::UpdateVSet(const size_t pi) {
    for (size_t ci = pi + 1; ci < this->match_vertex_.size(); ci++) {
        if ((pi > 1) and this->VSet(pi - 1, ci).size > 0) {
            /* match_vertex_[ith] and match_vertex[ci] connect for ith <= pi
             * pi > 1
             */
            auto &vset_i = this->VSet(pi - 1, ci);
            EarlyTerminateTrue(this->UpdateVSet(pi, ci, vset_i));
        } else if ((pi == 1) and this->IsConnected(0, ci)) {
            /* match_vertex_[ith] and match_vertex[ci] connect for ith <= pi
             * pi is 1
             */
            auto &nset_i = this->NSet(pi - 1, ci);
            EarlyTerminateTrue(this->UpdateVSet(pi, ci, nset_i));
        } else if (this->IsConnected(pi, ci)) {
            /* DSet
             * no match_vertex_[ith] and match_vertex_[ci] connect for ith < pi
             * match_vertex_[pi] and match_vertex_[ci] connect
             */
            auto &vset_o = this->VSet(pi, ci);
            auto &nset_i = this->NSet(pi, ci);
            /* find NeighborSet of vertices to be removed
             * dset_loop is only useful for labeled graphs
             * for unlabeled graphs, dset_loop is guaranteed non-empty
             */
            size_1d_t dset_loop;
            for (size_t ith = 0; ith < pi; ith++) {
                if (this->AllClusterIndex(ith, ci).size() > 0) {
                    dset_loop.push_back(ith);
                }
            }
            if (dset_loop.size()) {
                // DSet NeighborSet
                size_t iloop = dset_loop[0];
                auto &nset_1d = this->NSet1d(iloop, ci);
                if (this->MatchVertexLabel(iloop, ci)) {
                    DSet(vset_o, nset_i, this->result_[iloop], nset_1d);
                } else {
                    DSet(vset_o, nset_i, nset_1d);
                }
                for (size_t ith = 1; ith < dset_loop.size(); ith++) {
                    size_t jloop = dset_loop[ith];
                    auto &nset_1d = this->NSet1d(jloop, ci);
                    if (this->MatchVertexLabel(jloop, ci)) {
                        DSet(vset_o, vset_o, this->result_[jloop], nset_1d);
                    } else {
                        DSet(vset_o, vset_o, nset_1d);
                    }
                }
                DebugPrint(pi, ci, vset_o);
                EarlyTerminateSize0(vset_o);
            } else {
                // DSet vertex
                VertexSet dvs(pi);
                for (size_t ith = 0; ith < pi; ith++) {
                    if (this->MatchVertexLabel(ith, ci)) {
                        dvs.Add(this->result_[ith]);
                    }
                }
                if (dvs.size > 1) {
                    dvs.Sort();
                    vset_o.DSet(nset_i, dvs);
                    DebugPrint(pi, ci, vset_o);
                    EarlyTerminateSize0(vset_o);
                } else if (dvs.size == 1) {
                    vset_o.DSet(nset_i, dvs.Vertex(0));
                    DebugPrint(pi, ci, vset_o);
                    EarlyTerminateSize0(vset_o);
                } else {
                    // no-op
                    vset_o.size = 0;
                    vset_o.Copy(nset_i, 0);
                }
            }
        }
        /* this->match_vertex_[ith] and this->match_vertex_[ci] do not connect
         * for ith <= pi
         * therefore cannot compute a candidate VertexSet
         * for this->match_vertex_[ci]
         *
         * so skip computing VertexSet for this->match_vertex_[ci]
         */
    }
    return false;
}

} // namespace dynamic

} // namespace csr
