/*
 * homomorphism.cpp
 *
 *  Created on: 22:59 PM Monday Sep 25, 2023
 *      Author: hongt Hongtai Cao
 */

#include "include/csr/dynamic/homomorphism.hpp"

namespace csr {

namespace dynamic {

void Homomorphism::InitializeCandidateSet() {
    // same as EdgeInduce
    const size_t n = this->match_vertex_.size();
    if (n > 2) {
        this->vset_1d_.resize((n - 2) * (n - 1) / 2);
    }
    size_t capacity = (n - 1) * n / 2;
    this->nset_1d_.reserve(capacity);
    while (this->nset_1d_.size() < capacity) {
        this->nset_1d_.emplace_back(nullptr, 0);
    }
}

bool Homomorphism::UpdateVSet(const size_t pi) {
    for (size_t ci = pi + 1; ci < this->match_vertex_.size(); ci++) {
        if ((pi > 1) and this->VSet(pi - 1, ci).size > 0) {
            /* match_vertex_[ith] and match_vertex[ci] connect for ith <= pi
             * pi > 1
             */
            auto &vset_i = this->VSet(pi - 1, ci);
            EarlyTerminateTrue(this->UpdateVSet(pi, ci, vset_i));
        } else if ((pi == 1) and this->IsConnected(0, ci)) {
            /* match_vertex_[ith] and match_vertex[ci] connect for ith <= pi
             * pi is 1
             */
            auto &nset_i = this->NSet(pi - 1, ci);
            EarlyTerminateTrue(this->UpdateVSet(pi, ci, nset_i));
        } else if (this->IsConnected(pi, ci)) {
            /* DSet
             * no match_vertex_[ith] and match_vertex_[ci] connect for ith < pi
             * match_vertex_[pi] and match_vertex_[ci] connect
             *
             * Homomorphism allow matching the same vertex multiple times
             * just copy, a no-op
             */
            auto &vset_o = this->VSet(pi, ci);
            vset_o.size = 0;
            vset_o.Copy(this->NSet(pi, ci), 0);
        }
        /* this->match_vertex_[ith] and this->match_vertex_[ci] do not connect
         * for ith <= pi
         * therefore cannot compute a candidate VertexSet
         * for this->match_vertex_[ci]
         *
         * so skip computing VertexSet for this->match_vertex_[ci]
         */
    }
    return false;
}

} // namespace dynamic

} // namespace csr
