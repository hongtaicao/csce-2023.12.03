/*
 * utility.cpp
 *
 *  Created on: 3:14 AM Wednesday Aug 30, 2023
 *      Author: hongt Hongtai Cao
 */

#include <algorithm>        // std::count

#include "include/csr/graph.hpp"
#include "include/csr/utility.hpp"
#include "include/csr/vertexset.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"

namespace csr {

uint64_t COUNTER;
std::ofstream OUTPUT;
result_2d_t RESULT;

// local function
inline void InitializeBefore(const vid_t max_size) {
    /* the MAX_SIZE of VertexSet holds all candidate vertices
     * it should be the largest of the following
     * 1. max degree of the data graph per labels
     * 2. query_vertex_count - 1 because at most false candidates
     */
    COUNTER = 0;
    utility::InitializeLoopCounter();
    VertexSet::MAX_SIZE = max_size;
}

// cannot inline because these are public functions
#if !defined(COUNTING) and defined(LISTING)
uint64_t After(Config &config) {
    // counter lines in the output file
    std::ifstream in_file(config.SaveFile());
    return std::count(std::istreambuf_iterator<char>(in_file),
            std::istreambuf_iterator<char>(), '\n');
}

bool Before(Config &config, const vid_t max_size) {
    // return status. true: good. false: failure
    InitializeBefore(max_size);
    PrintLCTX("LISTING");
    const std::string &out_file = config.SaveFile();
    if (out_file.size()) {
        OUTPUT.open(out_file);
    } else {
        PrintLCTX("LISTING missing argument: " << Config::KeySaveFile);
        return false;
    }
    return true;
}
#elif !defined(COUNTING) and defined(MEMORY)
uint64_t After(Config &) {
    return RESULT.size();
}

bool Before(Config &, const vid_t max_size) {
    // return status. true: good. false: failure
    InitializeBefore(max_size);
    PrintLCTX("MEMORY");
    RESULT.clear();
    return true;
}
#else
uint64_t After(Config &) {
    return COUNTER;
}

bool Before(Config &, const vid_t max_size) {
    // return status. true: good. false: failure
    InitializeBefore(max_size);
    PrintLCTX("Default: COUNTING");
    COUNTER = 0;
    return true;
}
#endif

bool ExecuteByQueryName(Config &config, const Graph &graph, Logger &logger,
        expression_map_t &QUERY_PLAN, const vid_t max_size) {
    /* c++ error: qualified-id in declaration before '=' token
     * https://stackoverflow.com/a/55330102
     * should define first
     */
    if (QUERY_PLAN.count(config.QueryName())) {
        if (Before(config, max_size)) {
            const utility::timepoint_t &start = utility::GetTimepoint();
            QUERY_PLAN[config.QueryName()](graph);
            logger.DurationExecutionCompile = utility::GetDuration(start);
            logger.MatchCount = After(config);
            PrintCTX("DurationExecutionCompile(s)=");
            Print(logger.DurationExecutionCompile << " MatchCount=");
            PrintLine(logger.MatchCount);
            utility::PrintLoopCounter(true);
            return true;
        }
    } else {
        PrintLCTX("NotImplemented QueryName=" << config.QueryName());
    }
    return false;
}

} // namespace csr
