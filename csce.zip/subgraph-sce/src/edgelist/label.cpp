/*
 * label.cpp
 *
 *  Created on: 5:24 AM Friday Sep 15, 2023
 *      Author: hongt Hongtai Cao
 */

#include <algorithm>
#include <fstream>

#include "include/edgelist/label.hpp"
#include "include/utility/utility.hpp"

namespace edgelist {

bool LabelArrayComparator(const array4_t &, const array4_t &);

// local function
void BuildLabelArray1d(const edge_to_array4_t &edge_to_labelarray,
        array4_1d_t &labelarray_1d) {
    // compute the label set. ignore unconnected label
    string_set_t label_set;
    for (auto it = edge_to_labelarray.begin(); it != edge_to_labelarray.end();
            it++) {
        auto l_str = LabelarrayToString(it->second);
        if (not label_set.count(l_str)) {
            label_set.insert(l_str);
            labelarray_1d.push_back(it->second);
        }
    }
    // assign label id to each label based on sorting order
    std::sort(labelarray_1d.begin(), labelarray_1d.end(), LabelArrayComparator);
    DPrintLCTX("label set count: " << label_set.size());
}

bool LabelArrayComparator(const array4_t &a, const array4_t &b) {
    // sort in ascending order. return true if a < b
    if (a[0] < b[0]) {
        return true;
    } else if (a[0] > b[0]) {
        return false;
    }
    if (a[1] < b[1]) {
        return true;
    } else if (a[1] > b[1]) {
        return false;
    }
    if (a[2] < b[2]) {
        return true;
    } else if (a[2] > b[2]) {
        return false;
    }
    return a[3] < b[3];
}

// public function
void ReadLabelFileText(const std::string &label_file,
        string_index_t &clusterkey_index) {
    std::ifstream in(label_file.c_str());
    vid_t sl = 0, dl = 0;
    eid_t el = 0, tl = 0;
    while ((not in.eof()) and (in >> sl >> dl >> el >> tl)) {
        auto cluster_size = clusterkey_index.size();
        clusterkey_index[ToString4(sl, dl, el, tl)] = cluster_size;
    }
}

void WriteLabelFileText(const std::string &label_file,
        const edge_to_array4_t &edge_to_labelarray,
        string_index_t &clusterkey_index) {
    array4_1d_t labelarray_1d;
    BuildLabelArray1d(edge_to_labelarray, labelarray_1d);
    /* WriteLabelFileText
     * write text label file
     */
    utility::MkFileDir(label_file);
    std::ofstream out_label(label_file, std::ios::out);
    for (auto it = labelarray_1d.begin(); it != labelarray_1d.end(); it++) {
        // cannot combine into the same line
        csize_t index = clusterkey_index.size();
        clusterkey_index[LabelarrayToString((*it))] = index;
        for (auto label : *it) {
            out_label << label << " ";
        }
        out_label << std::endl;
    }
    out_label.close();
}

} // namespace edgelist
