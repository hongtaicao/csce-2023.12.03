/*
 * graph.cpp
 *
 *  Created on: 23:19 PM Friday Sep 15, 2023
 *      Author: hongt Hongtai Cao
 */

#include <algorithm>
#include <fstream>

#include "include/edgelist/graph.hpp"
#include "include/utility/config.hpp"
#include "include/utility/utility.hpp"

namespace edgelist {

// local function
inline void InsertEdge(const vid_t src, const vid_t dst, edge_map_t &out_edge) {
    if (not out_edge.count(src)) {
        out_edge[src] = vid_set_t();
    }
    out_edge[src].insert(dst);
}

// public function
void GetVertexLabel(const edge_map_t &out_edge, edge_to_array4_t &label_map,
        const size_t vertex_count, string_1d_t &vertex_to_label) {
    vertex_to_label.resize(vertex_count);
    for (const auto &v_neighbor : out_edge) {
        auto va = v_neighbor.first;
        for (const auto &vb : v_neighbor.second) {
            auto edge_str = std::to_string(va) + " " + std::to_string(vb);
            const auto &label_array = label_map[edge_str];
            vertex_to_label[va] = std::to_string(label_array[0]);
            vertex_to_label[vb] = std::to_string(label_array[1]);
        }
    }
}

void GetVertexSet(const edge_map_t &out_edge, vid_set_t &vertex_set) {
    for (const auto &v_neighbor : out_edge) {
        vertex_set.insert(v_neighbor.first);
        for (const auto &vb : v_neighbor.second) {
            vertex_set.insert(vb);
        }
    }
}

vid_t MaxDegree(const edge_map_1d_t &edge_map_1d) {
    vid_t max_degree = 0;
    for (const auto &edge_map : edge_map_1d) {
        for (const auto &pair : edge_map) {
            max_degree = std::max(max_degree, (vid_t) pair.second.size());
        }
    }
    return max_degree;
}

vid_t MaxVertex(const edge_map_t &out_edge) {
    vid_t max_vertex = 0;
    for (const auto &v_neighbor : out_edge) {
        if (v_neighbor.first > max_vertex) {
            max_vertex = v_neighbor.first;
        }
        for (const auto &vb : v_neighbor.second) {
            if (vb > max_vertex) {
                max_vertex = vb;
            }
        }
    }
    return max_vertex;
}

void ReadGraphText(bool has_label, const std::string &in_file,
        edge_map_t &out_edge, edge_to_array4_t &edge_to_labelarray) {
    /* read text graph as edge list with label
     * output argument meaning
     * out_edge: store edges as neighbor set, without labels
     * edge_to_labelarray: edge -> labels (sl, dl, el, tl)
     * labelarray_1d: all unique labels as a tuple (sl, dl, el, tl)
     */
    // need to convert it to a c-string if not c++11 or later.
    std::ifstream in(in_file.c_str());
    // open as text file
    /*
     * graph.txt format
     * 5 columns space separated file, all should be numbers
     * source vertex
     * destination vertex
     * source vertex label
     * destination vertex label
     * edge label
     */
    // read data.txt
    vid_t src = 0, dst = 0;
    // src label, dst label, edge label
    vid_t sl = DefaultLabel, dl = DefaultLabel;
    eid_t el = DefaultLabel;
    if (has_label) {
        while ((not in.eof()) and (in >> src >> dst >> sl >> dl >> el)) {
            InsertEdge(src, dst, out_edge);
            edge_to_labelarray[ToString2(src, dst)] =
                    array4_t { sl, dl, el };
        }
    } else {
        vid_t src = 0, dst = 0;
        while ((not in.eof()) and (in >> src >> dst)) {
            InsertEdge(src, dst, out_edge);
            edge_to_labelarray[ToString2(src, dst)] =
                    array4_t { sl, dl, el };
        }
    }
    DPrintLCTX("vertex out degree > 0 count: " << out_edge.size());
    DPrintLCTX("edge count: " << edge_to_labelarray.size());
    in.close();
    // assign topology label
    for (auto imap = out_edge.begin(); imap != out_edge.end(); imap++) {
        auto src = imap->first;
        for (auto dst : out_edge[src]) {
            if (src != dst) {
                // self loops should be ignored
                std::string e_str = ToString2(src, dst);
                if (out_edge.count(dst) and out_edge[dst].count(src)) {
                    // bi-directed edge
                    edge_to_labelarray[e_str][3] = BidirectedEdgeLabel;
                } else {
                    // out-going edge
                    edge_to_labelarray[e_str][3] = OutgoingEdgeLabel;
                    auto &l_1d = edge_to_labelarray[e_str];
                    // in-coming edge
                    std::string in_str = ToString2(dst, src);
                    edge_to_labelarray[in_str] = array4_t { l_1d[1],
                            l_1d[0], l_1d[2], IncomingEdgeLabel };
                }
            } else {
                PrintCTX("Ignore self loop [" << src << "]. Is a labeled ");
                PrintLine("graph read as unlabeled or vice versa?");
            }
        }
    }
}

vid_t ReadGraphTextToGraphs(Config &config, edge_map_1d_t &edge_map_1d,
        string_index_t &clusterkey_index) {
    /* vertex is required to be in range [0, max_vertex]
     * therefore vertex_count = max_vertex + 1
     */
    edge_map_t out_edge;
    edge_to_array4_t edge_to_labelarray;
    ReadGraphText(config.IsLabeled(), config.DataFile(), out_edge,
            edge_to_labelarray);
    // write label file
    WriteLabelFileText(config.LabelFile(), edge_to_labelarray,
            clusterkey_index);
    // create edge map per label id
    edge_map_1d.resize(clusterkey_index.size());
    vid_t max_vertex = 0;
    for (auto imap = out_edge.begin(); imap != out_edge.end(); imap++) {
        auto src = imap->first;
        max_vertex = std::max(max_vertex, src);
        for (auto dst : imap->second) {
            max_vertex = std::max(max_vertex, dst);
            auto l_str = LabelarrayToString(
                    edge_to_labelarray[ToString2(src, dst)]);
            InsertEdge(src, dst, edge_map_1d[clusterkey_index[l_str]]);
            if (not (out_edge.count(dst) and (out_edge[dst].count(src)))) {
                // add in-coming edge
                auto in_str = LabelarrayToString(
                        edge_to_labelarray[ToString2(dst, src)]);
                InsertEdge(dst, src, edge_map_1d[clusterkey_index[in_str]]);
            }
        }
    }
    if (max_vertex == 0) {
        // empty graph without vertices
        return 0;
    }
    return max_vertex + 1;
}

void WriteGraphText(string_index_t &edge_to_clusterindex,
        const std::string &label_file, const std::string &out_file) {
    // labelstr_index: map label string to label_id
    string_index_t labelstr_index;
    edgelist::ReadLabelFileText(label_file, labelstr_index);
    /* CreateLabelMap
     * reverse labelstr_index mapping
     */
    string_1d_t index_clusterkey;
    index_clusterkey.resize(labelstr_index.size());
    for (auto it = labelstr_index.begin(); it != labelstr_index.end(); it++) {
        index_clusterkey[it->second] = it->first;
    }
    /* note that edge_to_label_id contains
     * bi-directed, in-coming and out-going edges
     * but edge list should only contain (a, b) if a -> b
     * should remove edges if its topology label is in-coming
     */
    string_map_t edge_label_map;
    const std::string in_edge_label = std::to_string(IncomingEdgeLabel);
    for (const auto &pair : edge_to_clusterindex) {
        auto &cluster_key = index_clusterkey[pair.second];
        if (cluster_key.substr(cluster_key.size() - 1) != in_edge_label) {
            // topology label is always the last character
            edge_label_map[pair.first] = cluster_key;
        }
    }
    /* WriteGraphText
     * edge_label_map is always labeled
     * if all labels in edge_label_map are 0, total unique label count is 1
     * then everything shares the same label -> unlabeled
     */
    bool directed = false;
    string_set_t elabel_set, vlabel_set;
    for (const auto &cluster_key : index_clusterkey) {
        auto label_1d = utility::Split(cluster_key, ' ');
        vlabel_set.insert(label_1d[0]);
        vlabel_set.insert(label_1d[1]);
        elabel_set.insert(label_1d[2]);
        if (label_1d[3] == in_edge_label) {
            directed = true;
        }
    }
    const bool islabeled = (vlabel_set.size() > 1) or (elabel_set.size() > 1);
    utility::MkFileDir(out_file);
    std::ofstream out(out_file, std::ios::out);
    // find the number of unique labels
    PrintLCTX("write text file: "<< out_file);
    Print("write edge count=" << edge_label_map.size() << " labeled=");
    PrintLine(Bool_String(islabeled) << " directed=" << Bool_String(directed));
    Print("edges (in+out)=" << edge_to_clusterindex.size());
    Print(" labeled vertex=" << Bool_String(vlabel_set.size() > 1));
    Print(" edge=" << Bool_String(elabel_set.size() > 1));
    Print(" label count (vertex)=" << vlabel_set.size() << " (edge)=");
    PrintLine(elabel_set.size());
    /* parse edge_to_label_id into out_edge
     * edge_to_label_id contains in-coming edges
     * out_edge should not contain in-coming edges
     * edge_label_map does not contain in-coming edges
     */
    edge_map_t out_edge;
    for (const auto &pair : edge_to_clusterindex) {
        auto edge = utility::Split(pair.first, ' ');
        if (edge_label_map.count(pair.first)) {
            InsertEdge(std::stoi(edge[0]), std::stoi(edge[1]), out_edge);
        }
    }
    std::vector<vid_t> src_1d;
    for (auto it = out_edge.begin(); it != out_edge.end(); it++) {
        src_1d.push_back(it->first);
    }
    std::sort(src_1d.begin(), src_1d.end());
    for (vid_t src : src_1d) {
        auto neighbor = out_edge.at(src);
        std::vector<vid_t> dst_1d(neighbor.begin(), neighbor.end());
        std::sort(dst_1d.begin(), dst_1d.end());
        for (auto dst : dst_1d) {
            if (islabeled) {
                // labeled graph
                std::string label = edge_label_map[ToString2(src, dst)];
                label = label.substr(0, label.size() - 2);
                /* topology label is always the last character
                 * here removes the topology label and the leading space
                 */
                out << src << " " << dst << " " << label << std::endl;
            } else {
                // unlabeled graph
                out << src << " " << dst << std::endl;
            }
        }
    }
    out.close();
}

} // namespace edgelist
