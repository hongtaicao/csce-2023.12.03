/*
 * unlabeled.cpp
 *
 *  Created on: 15:47 PM Saturday 2022-10-29
 *      Author: Hongtai Cao
 */

#include <fstream>
#include <unordered_set>

#include "include/optim/query/unlabeled.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace query {

Unlabeled::Unlabeled(Config &c)
        : Base() {
    this->base = this;
    std::ifstream in(c.QueryFile().c_str());
    vid_t src, dst;
    std::unordered_set<vid_t> v_set;
    while ((not in.eof()) and (in >> src >> dst)) {
        v_set.insert(src);
        v_set.insert(dst);
        this->out_edge[src].insert(dst);
    }
    this->v_1d.assign(v_set.begin(), v_set.end());
    this->InitializeCounter();
}

Unlabeled::Unlabeled(edge_map_t &out_edge, const vid_set_t &v_set)
        : Base(out_edge, v_set) {
    // create a graph induced by vertex set v_set
    this->base = this;
    this->InitializeCounter();
}

} // namespace query

} // namespace optim
