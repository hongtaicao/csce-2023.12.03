/*
 * query.cpp
 *
 *  Created on: 19:29 PM Friday 2022-10-28
 *      Author: Hongtai Cao
 */

#include "include/algorithm/disjointset.hpp"
#include "include/optim/query.hpp"
#include "include/optim/query/base.hpp"
#include "include/optim/query/labeled.hpp"
#include "include/optim/query/unlabeled.hpp"
#include "include/utility/config.hpp"

namespace optim {

// public
vid_t Query::Degree(const vid_t vertex) {
    vid_t degree = 0;
    for (auto va : this->v_1d) {
        if (this->HasEdge(vertex, va) or this->HasEdge(va, vertex)) {
            degree++;
        }
    }
    return degree;
}

bool Query::HasEdge(const vid_t a, const vid_t b) {
    // return the number of such edges
    if (this->base->out_edge.count(a)) {
        if (this->base->out_edge[a].count(b)) {
            return true;
        }
    }
    return false;
}

/* cannot inline, otherwise
 * undefined reference to `optim::Query::Hash() const'
 */
size_t Query::Hash() const {
    return this->base->Hash(this);
}

vid_t Query::InDegree(const vid_t vertex) const {
    vid_t in_degree = 0;
    for (auto &pair: this->base->out_edge) {
        if (pair.second.count(vertex)) {
            in_degree++;
        }
    }
    return in_degree;
}

bool Query::IsEmpty() const {
    return not (this->size_b or this->size_s);
}

bool Query::IsomorphicTo(Query *other) {
    /* does not check if Query are the same size
     * compute isomorphic mapping that transform this -> other
     * this->v_1d[mapping[0]] => other->v_1d[0]
     * store result in other->mapping_1d, NOT other->base->mapping_1d
     */
    return this->base->IsomorphicTo(this, other);
}

bool Query::IsConnected() {
    // if there is a single connected component, then the graph is connected
    algorithm::DisjointSet<vid_t> component;
    // initialize
    for (const auto &v : this->v_1d) {
        component.Add(v);
    }
    /* query is induced on this->v_1d
     * and therefore out_edge may contain more vertexes
     */
    for (const auto &vi : this->v_1d) {
        if (this->base->out_edge.count(vi)) {
            const auto &neighbor_set = this->base->out_edge[vi];
            for (const auto &vj : this->v_1d) {
                if (neighbor_set.count(vj)) {
                    component.Union(vi, vj);
                }
            }
        }
    }
    return (component.Size() == 1);
}

/* cannot inline, otherwise
 * undefined reference to `optim::Query::Label(unsigned int)'
 */
vid_t Query::Label(const vid_t a) {
    // return vertex label
    return this->base->Label(a);
}

/* cannot inline, otherwise
 * undefined reference to `optim::Query::LabelId(unsigned int, unsigned int)'
 */
eid_t Query::Label(const vid_t a, const vid_t b) {
    // return edge label for vertex pair (a, b)
    return this->base->Label(a, b);
}

vid_t Query::OutDegree(const vid_t vertex) {
    if (this->base->out_edge.count(vertex)) {
        return this->base->out_edge[vertex].size();
    }
    return 0;
}

void Query::PrintDetail(bool end_of_line) const {
    Print("Query=" << this << " topology id=" << this->tid << " edge count");
    Print(" (bi-directed,single directed)=" << "(" << this->size_b << ",");
    Print(this->size_s << ") hash=" << this->Hash() << " vertex_1d=");
    for (const auto &vertex : this->v_1d) {
        Print(vertex << " ");
    }
    Print(" edge=");
    for (const auto &vi : this->v_1d) {
        if (this->base->out_edge.count(vi)) {
            const auto &neighbor_set = this->base->out_edge[vi];
            for (const auto &vj : this->v_1d) {
                if (neighbor_set.count(vj)) {
                    Print("(" << vi << "," << vj << ")");
                }
            }
        }
    }
    if (end_of_line) {
        PrintLine("");
    }
}

/* cannot inline, otherwise
 * undefined reference to `optim::Query::VertexOutNeighbor() const'
 */
edge_map_t &Query::VertexOutNeighbor() const {
    return this->base->out_edge;
}

// protected
void Query::InitializeCounter() {
    // this->size_b bi-directed edge
    // this->size_s single directed edge
    for (size_t j = 1; j < this->v_1d.size(); j++) {
        auto b = this->v_1d[j];
        for (size_t i = 0; i < j; i++) {
            auto a = this->v_1d[i];
            auto counter = this->HasEdge(a, b) + this->HasEdge(b, a);
            if (counter > 1) {
                this->size_b++;
            } else if (counter == 1) {
                this->size_s++;
            }
        }
    }
}

// constructor
Query::Query(Query *q, vid_1d_t &&vertex_1d)
        : base(q->base), tid(0), size_b(0), size_s(0) {
    // create a Query by induced on vertex set
    // always take the ownership of vertex_1d
    this->v_1d = vertex_1d;     // only allow move assignment of vector
    this->InitializeCounter();
}
Query::Query(Query *q, const vid_t a)
        : base(q->base), tid(0), size_b(0), size_s(0) {
    // create a Query by removing vertex a
    // update v_set_
    for (auto &v : q->v_1d) {
        if (v != a) {
            this->v_1d.push_back(v);
        }
    }
    this->InitializeCounter();
}

Query::~Query() {
    for (auto mapping : this->mapping_1d) {
        delete mapping;
    }
}

Query *ReadQuery(Config &config) {
    if (config.IsLabeled()) {
        return new query::Labeled(config);
    } else {
        return new query::Unlabeled(config);
    }
}

} // namespace optim
