/*
 * dag.cpp
 *
 *  Created on: 21:49 PM Thursday Nov 9, 2023
 *      Author: hongt
 */

#include "include/optim/graph.hpp"
#include "include/optim/ordergenerator/dag.hpp"
#include "include/optim/query.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace ordergenerator {

template<typename T>
bool HasFamily(const vid_set_t&, T&);

class CandidateComparator {
public:
    CandidateComparator(Graph &g, Query &q, vid_1d_t &p)
            : graph_(g), query_(q), permutation_(p) {
        this->family_size_.reserve(q.v_1d.size());
    }

    inline bool operator()(const vid_t a, const vid_t b) {
        vid_t size_a = this->family_size_[a];
        vid_t size_b = this->family_size_[b];
        if (size_a == size_b) {
            size_a = this->MinClusterSize(a);
            size_b = this->MinClusterSize(b);
            if (size_a == size_b) {
                size_a = this->graph_.LabelFrequency(this->query_.Label(a));
                size_b = this->graph_.LabelFrequency(this->query_.Label(b));
            }
        }
        return size_a < size_b;
    }

    void BuildApproximate(const vid_1d_t&, edge_map_t&, edge_map_t&);
    void BuildExact(const vid_1d_t&, edge_map_t&, edge_map_t&);

private:
    eid_t MinClusterSize(const vid_t);

    Graph &graph_;
    Query &query_;
    vid_map_t family_size_;
    vid_1d_t &permutation_;
};

void CandidateComparator::BuildApproximate(const vid_1d_t &match_order,
        edge_map_t &parent_to_child, edge_map_t &child_to_parent) {
    vid_set_t candidate;
    candidate.reserve(match_order.size());
    for (auto vertex : match_order) {
        if (not parent_to_child.count(vertex)) {
            this->family_size_[vertex] = 1;
            if (child_to_parent.count(vertex)) {
                for (auto parent : child_to_parent[vertex]) {
                    candidate.insert(parent);
                }
            }
        }
    }
    vid_set_t next_round;
    next_round.reserve(match_order.size());
    while (candidate.size()) {
        // candidate are vertices whose family size is know
        next_round.clear();
        for (auto vertex : candidate) {
            const vid_set_t &children = parent_to_child[vertex];
            bool flag = HasFamily(children, this->family_size_);
            if (flag) {
                if (this->family_size_.count(vertex)) {
                    continue;
                }
                vid_t counter = 1;
                for (auto child : children) {
                    counter += this->family_size_[child];
                }
                this->family_size_[vertex] = counter;
                if (child_to_parent.count(vertex)) {
                    for (auto parent : child_to_parent[vertex]) {
                        if (not this->family_size_.count(parent)) {
                            next_round.insert(parent);
                        }
                    }
                }
            } else {
                next_round.insert(vertex);
            }
        }
        std::swap(candidate, next_round);
    }
}

void CandidateComparator::BuildExact(const vid_1d_t &match_order,
        edge_map_t &parent_to_child, edge_map_t &child_to_parent) {
    /* bottom up dynamic programming to compute the family for each vertex
     * cannot compute family size directly because grandchildren can duplicate
     */
    edge_map_t vertex_to_family;
    vertex_to_family.reserve(match_order.size());
    vid_set_t candidate;
    candidate.reserve(match_order.size());
    for (auto vertex : match_order) {
        if (not parent_to_child.count(vertex)) {
            vertex_to_family[vertex].insert(vertex);
            if (child_to_parent.count(vertex)) {
                for (auto parent : child_to_parent[vertex]) {
                    candidate.insert(parent);
                }
            }
        }
    }
    vid_set_t next_round;
    next_round.reserve(match_order.size());
    while (candidate.size()) {
        // candidate are vertices whose family size is know
        next_round.clear();
        for (auto vertex : candidate) {
            const vid_set_t &children = parent_to_child[vertex];
            bool flag = HasFamily(children, vertex_to_family);
            if (flag) {
                if (vertex_to_family.count(vertex)) {
                    continue;
                }
                auto &family = vertex_to_family[vertex];
                family.insert(vertex);
                for (auto child : parent_to_child[vertex]) {
                    const auto grandchildren = vertex_to_family[child];
                    family.insert(grandchildren.begin(), grandchildren.end());
                }
                if (child_to_parent.count(vertex)) {
                    for (auto parent : child_to_parent[vertex]) {
                        if (not vertex_to_family.count(parent)) {
                            next_round.insert(parent);
                        }
                    }
                }
            } else {
                next_round.insert(vertex);
            }
        }
        std::swap(candidate, next_round);
    }
    for (const auto &pair : vertex_to_family) {
        this->family_size_[pair.first] = pair.second.size();
    }
}

eid_t CandidateComparator::MinClusterSize(const vid_t vb) {
    eid_t min_neighbor = this->graph_.VertexSize();
    for (auto va : this->permutation_) {
        if (this->query_.HasConnect(va, vb)) {
            std::string cluster_key = this->query_.ClusterKey(va, vb);
            if (this->graph_.HasCluster(cluster_key)) {
                eid_t neighbor_count = this->graph_.EdgeCount(
                        this->graph_.ClusterIndex(cluster_key));
                if (neighbor_count < min_neighbor) {
                    min_neighbor = neighbor_count;
                }
            }
        }
    }
    return min_neighbor;
}

void BuildDependency(Config &config, Graph &graph, Query &query,
        const vid_1d_t &match_order, edge_map_t &child_to_parent) {
    /* build dependency as a DAG
     * a depends on b is a<-b, child depends on parent
     * edges are stored as in-coming edges
     */
    child_to_parent.reserve(query.size_b + query.size_s);
    for (size_t cth = 1; cth < match_order.size(); cth++) {
        vid_t child = match_order[cth];
        vid_set_t &dependency = child_to_parent[child];
        dependency.reserve(child_to_parent.size());
        for (size_t pth = 0; pth < cth; pth++) {
            vid_t parent = match_order[pth];
            if (query.HasConnect(child, parent)) {
                // an edge is a dependency
                dependency.insert(parent);
            } else if (config.IsomorphismVertexInduce()) {
                if (dependency.size()) {
                    // candidate for child is built
                    std::string vp_label = ToString2(query.Label(parent),
                            query.Label(child));
                    for (const auto &et : graph.EdgeTopologyLabel(vp_label)) {
                        // data graph has edges between two labels
                        std::string cluster_key = vp_label + " " + et;
                        if (graph.EdgeCount(graph.ClusterIndex(cluster_key))) {
                            dependency.insert(parent);
                        }
                    }
                }
            }
        }
    }
}

template<typename T>
bool HasFamily(const vid_set_t &key_set, T &vertex_to_family) {
    for (auto key : key_set) {
        if (not vertex_to_family.count(key)) {
            return false;
        }
    }
    return true;
}

DAG::DAG(Config &config, Graph &graph, Query &query,
        const vid_1d_t &match_order) {
    if (query.v_1d.empty()) {
        this->in_range_ = false;
    }
    this->in_range_ = true;
    this->permutation.reserve(match_order.size());
    edge_map_t child_to_parent;
    BuildDependency(config, graph, query, match_order, child_to_parent);
    // make a reverse_map
    edge_map_t parent_to_child;
    parent_to_child.reserve(match_order.size());
    for (const auto &pair : child_to_parent) {
        for (auto parent : pair.second) {
            parent_to_child[parent].insert(pair.first);
        }
    }
    CandidateComparator compare(graph, query, this->permutation);
    compare.BuildExact(match_order, parent_to_child, child_to_parent);
    // topological sort on the DAG
    vid_set_t candidate, next_round;
    candidate.reserve(match_order.size());
    next_round.reserve(match_order.size());
    for (auto parent : match_order) {
        if (not child_to_parent.count(parent)) {
            // no parent -> dependency
            candidate.insert(parent);
        }
    }
    while (candidate.size()) {
        // break the tie of topological sort
        next_round.clear();
        for (auto parent : candidate) {
            this->permutation.push_back(parent);
            for (auto child : parent_to_child[parent]) {
                if (child_to_parent.count(child)) {
                    auto &parent_set = child_to_parent[child];
                    parent_set.erase(parent);
                    if (parent_set.empty()) {
                        next_round.insert(child);
                        child_to_parent.erase(child);
                    }
                }
            }
        }
        size_t offset = this->permutation.size() - candidate.size();
        std::sort(this->permutation.begin() + offset, this->permutation.end(),
                compare);
        std::swap(candidate, next_round);
    }
}

} // namespace ordergenerator

} // namespace optim
