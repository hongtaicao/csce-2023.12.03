/*
 * ri.cpp
 *
 *  Created on: Wednesday 16:28 PM Nov 8, 2023
 *      Author: hongt
 */

#include <algorithm>                    // std::swap

#include "include/optim/graph.hpp"
#include "include/optim/ordergenerator/ri.hpp"
#include "include/optim/query.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace ordergenerator {

// local method
inline void AddVertex(vid_1d_t &permutation, vid_set_t &visited,
        vid_set_t &pending, vid_t vertex) {
    permutation.push_back(vertex);
    visited.insert(vertex);
    pending.erase(vertex);
}

inline bool EnableDataGraph(Config &config) {
    return config.IsLabeled() and config.OrderGeneratorRIDataGraph();
}

bool HasConnect(Query &query, const vid_t va, const vid_set_t &v_1d) {
    for (auto vb : v_1d) {
        if (query.HasConnect(va, vb)) {
            return true;
        }
    }
    return false;
}

void MaxDegree(Query &query, vid_1d_t &v_1d) {
    vid_t max_degree = 0;
    for (auto vertex : query.v_1d) {
        vid_t degree = query.Degree(vertex);
        if (degree > max_degree) {
            max_degree = degree;
            v_1d.clear();
            v_1d.push_back(vertex);
        } else if (degree == max_degree) {
            v_1d.push_back(vertex);
        }
    }
}

void MinLabel(const Graph &graph, Query &query, const vid_1d_t &v1d_a,
        vid_1d_t &v1d_b) {
    vid_map_t vlabel_frequency;
    vlabel_frequency.reserve(v1d_a.capacity());
    vid_t min_count = graph.VertexSize();
    for (auto vertex : v1d_a) {
        vid_t label = query.Label(vertex);
        if (not vlabel_frequency.count(label)) {
            vlabel_frequency[label] = graph.LabelFrequency(label);
        }
        vid_t label_count = vlabel_frequency[label];
        if (label_count < min_count) {
            min_count = label_count;
            v1d_b.clear();
            v1d_b.push_back(vertex);
        } else if (label_count == min_count) {
            v1d_b.push_back(vertex);
        }
    }
}

void Rule1(Query &query, const vid_set_t &visited, const vid_set_t &pending,
        vid_1d_t &v_1d) {
    /* for va in pending, find the number of visited vb vertices such that
     * (vb, va) is connected
     */
    vid_t max_connect = 0;
    for (auto va : pending) {
        vid_t counter = 0;
        for (auto vb : visited) {
            if (query.HasConnect(vb, va)) {
                counter++;
            }
        }
        if (counter > max_connect) {
            max_connect = counter;
            v_1d.clear();
            v_1d.push_back(va);
        } else if (counter == max_connect) {
            v_1d.push_back(va);
        }
    }
    /* RI original paper rule 2 has a typo, the example is correct
     * the original implementation is faster in execution
     * Figure 2 shows RI break ties by choosing vertex with the smallest id
     */
    std::sort(v_1d.begin(), v_1d.end());
}

void Rule2(Query &query, const vid_set_t &visited, const vid_set_t &pending,
        const vid_1d_t &v1d_a, vid_1d_t &v1d_b) {
    /* v1d_a is a subset of pending from previous steps
     *
     * case 1: equation of the paper is the following
     * for va in pending, find the number from visited vb such that
     * (vb, vc) is connected, for any vc from pending
     * (va, vc) is connected
     *
     * case 2: example of the paper is the following
     * for va in pending, find the number from pending vb such that
     * (vc, va) is connected, for any vc from visited
     * (vc, vb) is connected
     *
     * case 2 is the original implementation
     * case 2 has better execution performance
     */
    vid_t max_count = 0;
    for (auto va : v1d_a) {
        vid_t counter = 0;
        for (auto vb : pending) {
            if (query.HasConnect(va, vb) and HasConnect(query, vb, visited)) {
                counter++;
            }
        }
        if (counter > max_count) {
            max_count = counter;
            v1d_b.clear();
            v1d_b.push_back(va);
        } else if (counter == max_count) {
            v1d_b.push_back(va);
        }
    }
}

void Rule3(Query &query, const vid_set_t &visited, const vid_set_t &pending,
        const vid_1d_t &v1d_a, vid_1d_t &v1d_b) {
    /* v1d_a is a subset of pending from previous steps
     *
     * for va in pending, find the number of vertices vb in pending such that
     * (va, vb) is connected
     * (vc, vb) is not connected for all vc in visited
     */
    vid_1d_t candidate;
    candidate.reserve(pending.size());
    for (auto va : pending) {
        if (not HasConnect(query, va, visited)) {
            candidate.push_back(va);
        }
    }
    vid_t max_count = 0;
    for (auto va : v1d_a) {
        vid_t counter = 0;
        for (auto vb : candidate) {
            if (query.HasConnect(va, vb)) {
                counter++;
            }
        }
        if (counter > max_count) {
            max_count = counter;
            v1d_b.clear();
            v1d_b.push_back(va);
        } else if (counter == max_count) {
            v1d_b.push_back(va);
        }
    }
}

void RuleDataGraph(Graph &graph, Query &query, const vid_set_t &pool,
        const vid_1d_t &v1d_a, vid_1d_t &v1d_b) {
    /* v1d_a is the candidate set
     * break ties of rules 1, 2 and 3
     */
    vid_t min_neighbor = graph.VertexSize();
    for (auto va : v1d_a) {
        vid_t neighbor_count = graph.VertexSize();
        for (auto vb : pool) {
            std::string cluster_key = query.ClusterKey(vb, va);
            if (graph.HasCluster(cluster_key)) {
                eid_t size = graph.EdgeCount(graph.ClusterIndex(cluster_key));
                if (size < neighbor_count) {
                    neighbor_count = size;
                }
            } else {
                // no such edges, no match result
                v1d_b.push_back(va);
                return;
            }
        }
        if (neighbor_count < min_neighbor) {
            min_neighbor = neighbor_count;
            v1d_b.clear();
            v1d_b.push_back(va);
        } else if (neighbor_count == min_neighbor) {
            // further break the tie by LabelFrequency
            vid_t freq_a = graph.LabelFrequency(query.Label(va));
            vid_t freq_b = graph.LabelFrequency(query.Label(v1d_b[0]));
            if (freq_a < freq_b) {
                v1d_b.clear();
            }
            v1d_b.push_back(va);
        }
    }
}

// public
RI::RI(Config &config, Graph &graph, Query &query)
        : OrderGenerator() {
    if (query.v_1d.empty()) {
        this->in_range_ = false;
        return;
    }
    this->in_range_ = true;
    const vid_t max_size = query.v_1d.size();
    std::sort(query.v_1d.begin(), query.v_1d.end());
    this->permutation.reserve(max_size);
    // candidate variable
    vid_1d_t v1d_a, v1d_b;
    v1d_a.reserve(max_size);
    v1d_b.reserve(max_size);
    // state variable
    vid_set_t visited, pending;
    visited.reserve(max_size);
    pending.reserve(max_size);
    MaxDegree(query, v1d_a);
    if ((v1d_a.size() > 1) and EnableDataGraph(config)) {
        MinLabel(graph, query, v1d_a, v1d_b);
        this->permutation.push_back(v1d_b[0]);
        visited.insert(v1d_b[0]);
    } else {
        // RI method
        this->permutation.push_back(v1d_a[0]);
        visited.insert(v1d_a[0]);
    }
    for (auto vertex : query.v_1d) {
        if (not visited.count(vertex)) {
            pending.insert(vertex);
        }
    }
    while (this->permutation.size() < query.v_1d.size()) {
        v1d_a.clear();
        v1d_b.clear();
        Rule1(query, visited, pending, v1d_a);
        if (v1d_a.size() == 1) {
            AddVertex(this->permutation, visited, pending, v1d_a[0]);
            continue;
        } else if (EnableDataGraph(config)) {
            v1d_b.clear();
            RuleDataGraph(graph, query, visited, v1d_a, v1d_b);
            if (v1d_b.size() == 1) {
                AddVertex(this->permutation, visited, pending, v1d_b[0]);
                continue;
            }
            std::swap(v1d_a, v1d_b);
        }
        v1d_b.clear();
        Rule2(query, visited, pending, v1d_a, v1d_b);
        if (v1d_b.size() == 1) {
            AddVertex(this->permutation, visited, pending, v1d_b[0]);
            continue;
        } else if (EnableDataGraph(config)) {
            v1d_a.clear();
            RuleDataGraph(graph, query, pending, v1d_b, v1d_a);
            if (v1d_a.size() == 1) {
                AddVertex(this->permutation, visited, pending, v1d_a[0]);
                continue;
            }
        } else {
            std::swap(v1d_a, v1d_b);
        }
        v1d_b.clear();
        Rule3(query, visited, pending, v1d_a, v1d_b);
        if (v1d_b.size() == 1) {
            AddVertex(this->permutation, visited, pending, v1d_b[0]);
            continue;
        } else if (EnableDataGraph(config)) {
            v1d_a.clear();
            RuleDataGraph(graph, query, pending, v1d_b, v1d_a);
            if (v1d_a.size() == 1) {
                AddVertex(this->permutation, visited, pending, v1d_a[0]);
                continue;
            }
            std::swap(v1d_a, v1d_b);
        }
        AddVertex(this->permutation, visited, pending, v1d_b[0]);
    }
}

} // namespace ordergenerator

} // namespace optim
