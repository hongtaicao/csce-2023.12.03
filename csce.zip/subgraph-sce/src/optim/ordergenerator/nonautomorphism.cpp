/*
 * nonautomorphism.cpp
 *
 *  Created on: 2:12 AM Thursday 2023-4-20
 *      Author: Hongtai Cao
 */

#include <algorithm>        // std::permutation
#include <cstdlib>          // size_t

#include "include/optim/ordergenerator/nonautomorphism.hpp"

namespace optim {

namespace ordergenerator {

bool NonAutomorphism::IsNewOrder() {
    /* return true if this->permutation is a new order
     * index automorphic order generated from it
     * in order to work correctly
     * this->mapping_1d_[0] should be identity permutation
     * this is guaranteed by default (the way mapping_1d is generated)
     */
    std::string key = "";
    for (auto &x : this->permutation) {
        key += std::to_string(x) + "_";
    }
    if (this->order_set_.count(key)) {
        /* there is no need to index key under mapping_1d
         * because they are already indexed
         */
        return false;
    }
    // a new order
    DPrintCTX("new order=" << key << " skip order=");
    this->order_set_.insert(key);
    for (size_t i = 1; i < this->mapping_1d_.size(); i++) {
        /* skip 0-th mapping because it is identity mapping
         * and is inserted above
         */
        auto &mapping = (*this->mapping_1d_[i]);
        key = ""; // reset
        for (auto index : this->permutation) {
            /* isomorphic mappings are permutation of the identity mapping
             * if view key as a correspondence of the identity mapping
             * then isomorphic keys can be obtained using
             * the key to permute isomorphic mappings
             */
            key += std::to_string(mapping[index]) + "_";
        }
        this->order_set_.insert(key);
        DPrint(key << " ");
    }
    DPrintLine("");
    return true;
}

void NonAutomorphism::Next() {
    while (std::next_permutation(this->permutation.begin(),
            this->permutation.end())) {
        if (this->IsNewOrder()) {
            return;
        }
    }
    this->in_range_ = false;
}

NonAutomorphism::NonAutomorphism(vid_2d_t &mapping_1d)
        : in_range_(true), mapping_1d_(mapping_1d) {
    // does not check if mapping_1d is empty
    auto size = mapping_1d[0]->size();
    this->permutation.resize(size);
    for (size_t i = 0; i < size; i++) {
        this->permutation[i] = i;
    }
    this->IsNewOrder();
}

} // namespace ordergenerator

} // namespace optim
